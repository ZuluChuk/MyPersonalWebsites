//////////////////
// Dependencies //
//////////////////
//  clientlib/scripts/philips/philips.js
//  clientlib/scripts/vendor/viewport.js

window.philips.responsive.viewports = (function(
    
    // Arguments
    philips,
    viewport
    
) {
    'use strict';

    var globalViewports = [
        {
            name: 'vp-xs',
            width: [ 0 ], 
            mediaExp: '( min-width:0px )'
        },
        {
            name: 'vp-s',
            width: [ 451 ],
            mediaExp: '( min-width:451px )'
        },
        {
            name: 'vp-m',
            width: [ 701 ],
            mediaExp: '( min-width:701px )'
        },
        {
            name: 'vp-l',
            width: [ 961 ],
            mediaExp: '( min-width:961px )'
        },
        {
            name: 'vp-xl',
            width: [ 1024 ],
            mediaExp: '( min-width:1024px )'
        }
    ];
   
    return viewport( globalViewports, {
        modernize: true
    });
}(
        
    // Dependencies
    window.philips,
    window.viewport
    
));