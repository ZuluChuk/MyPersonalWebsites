//////////////////
// Dependencies //
//////////////////
//  clientlib/scripts/philips/vendor/jquery/jquery-1.10.1.min.js (or 2.0.2)
//  clientlib/scripts/philips/vendor/pubsub.js
//  clientlib/scripts/philips/philips.js
//  clientlib/scripts/vendor/jquery/jquery.custom-flexslider.js
//  clientlib/scripts/philips/components/aggregated/callout-video.js

window.philips.components.aggregated.altTopicFeatured = (function(

    // Dependency arguments
    pubsub,
    tabs,
    calloutVideo
) {
    'use strict';

    /**
     * Namespace for Related Products & Services component.
     *
     * @namespace component
     * @private
     */
    var component = {

         /**
         * Stores the pubsub channel names.
         *
         * @property            channels
         * @memberof            component
         */
        channel: {
            tabs: {
                ready: 'featured/tabs/ready',
                show: 'featured/tabs/show',
                hide: 'featured/tabs/hide'
            }
        },
        
        /**
         * Stores the component's various selectors.
         *
         * @property            selectors
         * @memberof            component
         */
        selectors: {
            context: '.p-alt-multi-video',
            tabToggle: '.p-tabs-nav',
            tabContent: '.p-tab-content'
        },
        
        /**
         * Stores the component's various class names.
         *
         * @property            classes
         * @memberof            component
         */
        classes: {
            tabActive: 'p-tabs-nav-active'
        },

        /**
         * Kicks off component's initiation.
         *
         * @method              init
         * @memberof            component
         * @returns {Object}    component
         */
        init: function() {
            
            this.context = $( this.selectors.context );
            
            this.tabs();
            calloutVideo( this.context );

            return this;
        },
        
        /**
         * Facilitates the tabbing functionality.
         *
         * @method              tabs
         * @memberof            component
         */
        tabs: function() {
            
            var self = this,
                related = this.context,
                channel = self.channel,
                toggleNav = related.find( this.selectors.tabToggle ),
                panels = related.find( this.selectors.tabContent );

            tabs.create( toggleNav, panels, { 
                activeClass: this.classes.tabActive,
                ready: function( state ) {
                    pubsub.publish( channel.tabs.ready, state );
                },
                show: function( state ) {
                    pubsub.publish( channel.tabs.show, state );
                },
                hide: function( state ) {
                    pubsub.publish( channel.tabs.hide, state );
                }
            });
        }

    };

    return component.init();

}(
    // Dependencies
    window.PubSub,
    window.philips.libs.tabs,
    window.philips.components.aggregated.calloutVideo
));