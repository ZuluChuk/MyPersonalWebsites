//////////////////
// Dependencies //
//////////////////
//	clientlib/scripts/vendorsclientlib/scripts/philips/jquery/jquery-1.10.1.min.js (or 2.0.2)
//	clientlib/scripts/philips/philips.js
//  clientlib/scripts/vendor/pubsub.js
//	clientlib/scripts/philips/libs/tabs.js

window.philips.components.aggregated.productDetailGallery = (function(
    // Dependency arguments
    pubsub,
    tabs
) {
	'use strict';

    /**
     * Namespace for Related Products & Services component.
     *
     * @namespace component
     * @private
     */
    var component = {
        
        /**
         * Stores the pubsub channel names.
         *
         * @property            channels
         * @memberof            component
         */
        channel: {
            tabs: {
                ready: 'gallery/tabs/ready',
                show: 'gallery/tabs/show',
                hide: 'gallery/tabs/hide'
            },
            thumbs: {
                selected: 'gallery/thumbs/selected'
            }
        },
        
        /**
         * Stores the components used class names.
         *
         * @property            selectors
         * @memberof            component
         */
        selectors: {
            activeClass: 'p-active',
            section: '.p-product-image-gallery',
            tabToggle: '.p-toggle-nav',
            tabContent: '.p-product-detail-tab-content',
            tabActive: 'p-toggle-nav-active',
            carousel: '.p-carousel',
            thumbList: '.p-product-image-gallery-thumbs a',
            galleryImg: '.p-product-image-gallery-full img',
            zoomImg: '.p-product-image-gallery-zoom img',
            zoomBtn: '.p-product-zoom'
        },
        
        /**
         * Kicks off component's initiation.
         * 
         * @method              init
         * @memberof            component
         * @returns {Object}    component
         */
        init: function() {
            
            this.context = $( this.selectors.section );
            
            this.tabs();
            this.carousels();
            this.gallery();
            this.zoom();

            return this;
        },
        
        /**
         * Facilitates the tabbing functionality.
         *
         * @method              tabs
         * @memberof            component
         */
        tabs: function() {
            
            var self = this,
                gallery = this.context,
                channel = self.channel,
                toggleNav = gallery.find( this.selectors.tabToggle ),
                panels = gallery.find( this.selectors.tabContent );
                
            tabs.create( toggleNav, panels, { 
                activeClass: this.selectors.tabActive,
                hide: function( state ) {
                    pubsub.publish( channel.tabs.hide, state );
                }
            });
        },
        
        /**
         * Facilitates the components carousel functionality.
         *
         * @method              carousels
         * @memberof            component
         */
        carousels: function() {
            
            var el = this.context.find( this.selectors.carousel );

            var options = {
                move: 1,
                maxItems: 1,
                minItems: 1,
                slideshow: false,
                controlNav: false,
                animation: 'slide',
                prevText:'&#xe014;',
                nextText:'&#xe013;',
                selector: 'ul > li',
                animationLoop: false,
                direction: 'vertical',
                namespace: 'p-carousel-'
            };
            
            el.flexslider( options );
        },
        
        /**
         * Facilitates the gallery functionality.
         *
         * @method              gallery
         * @memberof            component
         */
        gallery: function() {
            
            var self = this,
                context = self.context,
                panels = context.find( self.selectors.tabContent );
            
            $.each( panels, function(i) {
                
                var panel = panels.eq(i),
                    thumbs = panel.find( self.selectors.thumbList ),
                    full = panel.find( self.selectors.galleryImg );
                
                var handleGallery = function(e) {
                    
                    var thumb = $( this ),
                        url = thumb.attr( 'href' );
                    
                    e.preventDefault();
                    
                    pubsub.publish( self.channel.thumbs.selected, thumb );
                    thumbs.removeClass( self.selectors.activeClass );
                    thumb.addClass( self.selectors.activeClass );
                    full.attr( 'src', url );
                };
                
                thumbs.on( 'click touchend', handleGallery );
                
            });
        },
        
        /**
         * Facilitates the image zoom functionality.
         *
         * @method              zoom
         * @memberof            component
         */
        zoom: function() {
            
            var self = this,
                active = false,
                context = self.context,
                channel = self.channel,
                btn = context.find( self.selectors.zoomBtn ),
                panel = btn.parents( self.selectors.tabContent ),
                image = context.find( self.selectors.zoomImg );
            
            panel.data( 'zoomFeature', image );
            
            var enableZoom = function() {
                
                image.elevateZoom({
                    responsive: true,
                    zoomType: 'inner'
                });
                
                btn.addClass( self.selectors.activeClass );                
                active = true;
            };
            
            var disableZoom = function() {

                btn.removeClass( self.selectors.activeClass );
                image.removeData( 'elevateZoom' );
                image.removeData( 'zoomImage' );
                $( '.zoomContainer' ).remove();
                
                active = false;
            };
            
            var changeImage = function( src ) {
                
                if ( !src ) {
                    return;
                }
                image.attr( 'data-zoom-image', src );
            };
            
            var handleZoom = function() {
                
                if ( active ) { 
                    disableZoom();
                } else {
                    enableZoom();
                }
            };
            
            var handleDisable = function( panel ) {
                
                if ( !panel.data( 'zoomFeature' ) ) {
                    return;
                }
                
                disableZoom();
            };
            
            btn.on( 'click', handleZoom );
            pubsub.subscribe( channel.thumbs.selected, function( channel, thumb ) {
                handleDisable( thumb.parents( self.selectors.tabContent ) );
                changeImage( thumb.attr( 'data-zoom-image' ) );
            });
            pubsub.subscribe( channel.tabs.hide, function( channel, state ) {
                handleDisable( state.section );
            });
        }
        
    };
    
    return component.init();

}(
    // Dependencies
    window.PubSub,
    window.philips.libs.tabs
));
