//////////////////
// Dependencies //
//////////////////
//	clientlib/scripts/vendorsclientlib/scripts/philips/jquery/jquery-1.10.1.min.js (or 2.0.2)
//	clientlib/scripts/philips/philips.js
//  clientlib/scripts/vendor/pubsub.js
//	clientlib/scripts/philips/libs/tabs.js

window.philips.components.aggregated.productDetailFeatures = (function(
    // Dependency arguments
    pubsub,
    tabs
) {
	'use strict';
    
    
    /**
     * Namespace for Related Products & Services component.
     *
     * @namespace component
     * @private
     */
    var component = {
        
        /**
         * Stores the pubsub channel names.
         *
         * @property            channels
         * @memberof            component
         */
        channel: {
            tabs: {
                ready: 'featuresSpecs/tabs/ready',
                show: 'featuresSpecs/tabs/show',
                hide: 'featuresSpecs/tabs/hide'
            }
        },
        
        /**
         * Stores the components used class names.
         *
         * @property            selectors
         * @memberof            component
         */
        selectors: {
            activeClass: 'p-active',
            section: '.p-product-features-specifications',
            tabToggle: '.p-toggle-nav',
            tabContent: '.p-product-detail-tab-content',
            tabActive: 'p-toggle-nav-active',
            carousel: '.p-carousel'
        },
        
        /**
         * Kicks off component's initiation.
         * 
         * @method              init
         * @memberof            component
         * @returns {Object}    component
         */
        init: function() {
            
            this.context = $( this.selectors.section );
            
            this.carousel();
            this.tabs();

            return this;
        },
        
        /**
         * Facilitates the tabbing functionality.
         *
         * @method              tabs
         * @memberof            component
         */
        tabs: function() {
            
            var self = this,
                context = self.context,
                channel = self.channel,
                toggleNav = context.find( self.selectors.tabToggle ),
                panels = context.find( self.selectors.tabContent );
                
            tabs.create( toggleNav, panels, { 
                activeClass: self.selectors.tabActive,
                ready: function( state ) {
                    pubsub.publish( channel.tabs.ready, state );
                },
                show: function( state ) {
                    pubsub.publish( channel.tabs.show, state );
                },
                hide: function( state ) {
                    pubsub.publish( channel.tabs.hide, state );
                }
            });
            
            // @FLAG: Allows the tabs to control the prev/next of the carousel. Holding on to this for a bit incase it's needed. | ryanfitzer on 07-25-2013
            /*
            var self = this,
                context = this.context,
                carousel = context.find( this.selectors.carousel ),
                control = carousel.data( 'flexslider' ),
                toggleNav = context.find( this.selectors.tabToggle ),
                items = toggleNav.find( 'li' ),
                activeTab = items.eq(0);
            
            var update = function(e) {
                
                var element = $( this ),
                    isActive = element.hasClass( self.selectors.tabToggle ),
                    action = element.hasClass( 'prev' ) ? 'prev' : 'next';
                
                e.preventDefault();
                
                if ( isActive ) { return; }
                
                self.handleTabs( element.index() );
                control.flexAnimate( control.getTarget( action ) );
            };
            
            // Simple API for other methods to update tab state as needed.
            self.handleTabs = function( index ) {
                
                activeTab.removeClass( self.selectors.tabActive );
                activeTab = items.eq( index );
                activeTab.addClass( self.selectors.tabActive );
            };
            
            toggleNav.on( 'click touchend', 'li', update );
            */
        },
        
        /**
         * Facilitates the components carousel functionality.
         *
         * @method              carousel
         * @memberof            component
         */
        carousel: function() {
            
            var context = this.context,
                channel = this.channel,
                tabsViewed = false,
                carousels = context.find( this.selectors.carousel );
            
            var tabsHandler = function( chnl, state ){
                
                var index = state.index,
                    carousel = carousels.eq( index );
                
                var options = {
                    move: 1,
                    maxItems: 1,
                    minItems: 1,
                    slideshow: false,
                    animation: 'slide',
                    selector: 'ul > li',
                    animationLoop: false,
                    namespace: 'p-carousel-',
                    itemWidth: carousel.find( '> ul' ).width()
                };
                
                if ( tabsViewed ) { return; }
                
                carousel.flexslider( options );
                
                if ( chnl === channel.tabs.show ) {
                    tabsViewed = true;
                }
            };
            
            pubsub.subscribe( channel.tabs.ready, tabsHandler );
            pubsub.subscribe( channel.tabs.show, tabsHandler );
        }
        
    };
    
    return component.init();
        
}(
    // Dependencies
    window.PubSub,
    window.philips.libs.tabs
));
