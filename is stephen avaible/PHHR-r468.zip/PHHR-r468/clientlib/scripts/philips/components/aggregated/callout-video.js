//////////////////
// Dependencies //
//////////////////
//  clientlib/scripts/vendorsclientlib/scripts/philips/jquery/jquery-1.10.1.min.js (or 2.0.2)
//  clientlib/scripts/philips/philips.js
//  clientlib/scripts/vendor/jquery/jquery.magnific-popup.min.js

window.philips.components.aggregated.calloutVideo = (function() {
    'use strict';

    var module = {
        
        /**
         * Stores the module's used class names.
         *
         * @property selectors
         * @memberof module
         */
        selectors: {
            cta: '.p-video-play-arrow, .p-video-still, .cta'
        },

        /**
         * Kicks off module's initiation.
         *
         * @method init
         * @memberof module
         * @param {Object} A jQuery element representing the context of the module.
         * @returns {Object} module
         */
        init: function( context ) {

            this.context = context;

            this.modal();
        },
        
        /**
         * Creates a modal to hold the video player.
         *
         * @todo Placehodler until video player is ready.
         * @method  videoModal
         * @memberof module
         */
        modal: function() {

            var el = this.context.find( this.selectors.cta );
            
            
            /*
                TODO Placehodler until video player is ready.
            */
            el.magnificPopup({
                items: {
                    src: 'clientlib/images/fpo/video.jpg'
                },
                type: 'image'
            });
        }
    };
    
    return function( context ) {
        module.init( context );
    };

}(
        
    // Dependencies
    jQuery,
    window.philips
    
));
