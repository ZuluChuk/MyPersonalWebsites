//////////////////
// Dependencies //
//////////////////
//  clientlib/scripts/vendor/jquery/jquery-1.10.1.min.js (or 2.0.2)
//  clientlib/scripts/vendor/jquery/jquery.magnific-popup.min.js
//  clientlib/scripts/philips/philips.js

window.philips.components.aggregated.topicHero = (function(
    
    // Arguments
    
) {
    'use strict';

    /**
     * Namespace for Product Detail Hero component.
     *
     * @namespace component
     * @private
     */
    var component = {
        
        /**
         * Stores the components used class names.
         *
         * @property            selectors
         * @memberof            component
         */
        selectors: {
            context: '#topics-hub-hero',
            moreInfo: '.cta-button'
        },

        /**
         * Kicks off component's initiation.
         *
         * @method              init
         * @memberof            component
         * @returns {Object}    component
         */
        init: function() {

            this.context = $( this.selectors.context );

            this.moreInfo();

            return this;
        },
        
        /**
         * Creates a modal to show more info for the selected more-info CTA.
         *
         * @method              moreInfo
         * @memberof            component
         */
        moreInfo: function() {

            var el = this.context.find( this.selectors.moreInfo );
            
            var markup = [
                '<div class="p-iframe">',
                '<div class="mfp-close"></div>',
                '<iframe class="mfp-iframe" frameborder="0" allowfullscreen></iframe>',
                '</div>'
            ].join('');
            
            el.each( function( i, item ) {
                
                $( item ).magnificPopup({
                    type: 'iframe',
                    iframe: {
                        markup: markup
                    },
                    callbacks: {
                        beforeOpen: function() {
                        
                            var target = this.ev,
                                typeClass = 'p-iframe-type-' + target.data( 'type' );
                                
                            this.contentContainer.addClass( typeClass );
                        }
                    }
                });
            });
        }
    };

    return component.init();

}(
    
    // Dependencies
        
));