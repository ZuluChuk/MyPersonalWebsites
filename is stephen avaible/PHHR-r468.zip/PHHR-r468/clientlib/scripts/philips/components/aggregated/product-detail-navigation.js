//////////////////
// Dependencies //
//////////////////
//  clientlib/scripts/vendorsclientlib/scripts/philips/jquery/jquery-1.10.1.min.js (or 2.0.2)
//  clientlib/scripts/philips/philips.js
//  clientlib/scripts/vendor/jquery/jquery.scrollto.js
//  clientlib/scripts/vendor/jquery/jquery.waypoints.min.js
//  clientlib/scripts/vendor/jquery/jquery.waypoints-sticky.min.js

window.philips.components.aggregated.productDetailNavigation = (function(){
    'use strict';
    
    /**
     * Namespace for Product Detail Sticky Navigation component.
     *
     * @namespace component
     * @private
     */
    var component = {
        
        cache: {},
        
        /**
         * Holds class names for used elements.
         *
         * @property            classes
         * @memberof            component
         */
        classes: {
            active: 'active',
            menuActive: 'p-dropdown-active'
        },

        /**
         * Holds class names for used elements.
         *
         * @property            classes
         * @memberof            component
         */
        selectors: {
            section: '.p-product-tab-nav'
        },
        
        /**
         * Holds state info for the component.
         *
         * @property            state
         * @memberof            component
         */
        state: {
            curItem: null
        },
        
        /**
         * Kicks off component's initiation.
         *
         * @method              init
         * @memberof            component
         * @returns {Object}    component
         */
        init: function() {

            this.context = $( this.selectors.section );

            this.scrollTabs();
            this.cacheElements();
            this.menu();
            this.sticky();
            this.highlight();
            
            return this;
        },
        
         /**
         * Scrolling Tab Navigation
         * 
         *
         * @method              scrollTabs
         * @memberof            component
         */
        scrollTabs: function() {
            
            this.context.localScroll({
                hash: true,
                onBefore: function(e) {
                    if (!e) {
                        return false;
                    }
                }
            });
        },

        /**
         * Cache for elements.
         * @todo Use a selectors property for storing class name strings.
         *
         * @method              cacheElements
         * @memberof            component
         */
        cacheElements: function() {
            
            var els = {};
            
            els.nav = $( '.p-product-tab-nav' );
            els.menu = els.nav.find( '.p-product-mobile-tab-nav' );
            els.contentItems = $( '.p-product-detail-tab-container' );
            
            this.cache = $.extend( this.cache, els );
        },
        
        /**
         * Toggle the dropdown of the nav menu.
         *
         * @method              menu
         * @memberof            component
         */
        menu: function() {
            
            var self = this,
                cache = this.cache;

            cache.menu.on( 'click', function() {
                cache.nav.toggleClass( self.classes.menuActive );
            });
            
        },
        
        /**
         * Facilitate a the sticky nav functionality.
         *
         * @method              sticky
         * @memberof            component
         */
        sticky: function() {

            this.cache.nav.waypoint( 'sticky' );
        },
        
        /**
         * Facilitate highlighting the different sections of the nav as the user scrolls.
         *
         * @method              highlight
         * @memberof            component
         */
        highlight: function() {
            
            var timeout,
                self = this,
                cache = this.cache,
                state = self.state,
                items = cache.contentItems,
                activeClass = this.classes.active;

            var handler = function( direction ) {

                var content = this,
                    id = content.id,
                    nav = self.cache.nav,
                    isDown = direction === 'down',
                    navItem = nav.find( '[href="#' + id + '"]'),
                    prevItem = $( content ).waypoint( 'prev' ),
                    prevItemId = prevItem[0].id,
                    prevNavItem = prevItemId ? nav.find( '[href="#' + prevItemId + '"]') : false;
                
                if ( isDown ) {
                    
                    if ( state.curItem[0] === navItem[0] ) { return; }
                    state.curItem.removeClass( activeClass );
                    navItem.addClass( activeClass );
                    state.curItem = navItem;
                }
                else {
                    
                    if ( !prevNavItem ) { return; }
                    
                    state.curItem.removeClass( activeClass );
                    prevNavItem.addClass( activeClass );
                    state.curItem = prevNavItem;
                }
            };
            
            var refresh = function() {
                
                $.waypoints( 'refresh' );
            };
            
            var throttle = function() {

                if ( timeout ) {
        
                    clearTimeout( timeout );
                    
                    timeout = setTimeout( refresh, 100 );
                    
                    return;
                }
      
                timeout = setTimeout( refresh, 100 );
            };
            
            // Refresh calculations after all carousels are inited.
            $( document ).on( 'start.flexslider', throttle );
            
            // Set current item state
            state.curItem = this.cache.nav.find( 'li a.' + activeClass );
            
            // Init waypoints
            items.waypoint( handler, {
                offset: 46
            });
        }
    };
    
    component.init();

}());
