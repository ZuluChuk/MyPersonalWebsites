//////////////////
// Dependencies //
//////////////////
//  clientlib/scripts/vendor/jquery/jquery-1.10.1.min.js (or 2.0.2)
//  clientlib/scripts/philips/philips.js
//  clientlib/scripts/philips/components/aggregated/callout-video.js

window.philips.components.aggregated.specialtyHubHero = (function(
    
    // Arguments
    $,
    philips,
    calloutVideo
    
) {
    'use strict';

    /**
     * Namespace component.
     *
     * @namespace component
     * @private
     */
    var component = {
        
        /**
         * Stores the component's used class names.
         *
         * @property            selectors
         * @memberof            component
         */
        selectors: {
            context: '.p-cardiology-hub-hero'
        },

        /**
         * Kicks off component's initiation.
         *
         * @method              init
         * @memberof            component
         * @returns {Object}    component
         */
        init: function() {

            this.context = $( this.selectors.context );

            calloutVideo( this.context );

            return this;
        }
        
    };

    return component.init();

}(
    
    // Dependencies
    jQuery,
    window.philips,
    window.philips.components.aggregated.calloutVideo
    
));
