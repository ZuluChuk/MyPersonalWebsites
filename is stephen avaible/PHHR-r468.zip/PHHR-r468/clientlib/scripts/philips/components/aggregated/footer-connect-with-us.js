//////////////////
// Dependencies //
//////////////////
//  clientlib/scripts/vendorsclientlib/scripts/philips/jquery/jquery-1.10.1.min.js (or 2.0.2)
//  clientlib/scripts/philips/philips.js
//  clientlib/scripts/vendor/jquery/jquery.magnific-popup.min.js

window.philips.components.aggregated.footerConnect = (function(){
    'use strict';

    /**
     * Namespace for Connect with Us footer component.
     *
     * @namespace component
     * @private
     */
    var component = {

        selectors: {
            section: '.p-footer-connect-with-us',
            emailCTA: '.p-connect-content-sales-email'
        },

        /**
         * Kicks off component's initiation.
         *
         * @method              init
         * @memberof            component
         * @returns {Object}    component
         */
        init: function() {

            this.context = $( this.selectors.section );

            this.emailModal();

            return this;
        },
        
        /**
         * Creates a modal to hold the email contact form.
         *
         * @method              emailModal
         * @memberof            component
         */
        emailModal: function() {
            
            var el = this.context.find( this.selectors.emailCTA );
            
            var markup = [
                '<div class="p-iframe">',
                '<div class="mfp-close"></div>',
                '<iframe class="mfp-iframe" frameborder="0" allowfullscreen></iframe>',
                '</div>'
            ].join('');
            
            el.magnificPopup({
                type: 'iframe',
                iframe: {
                    markup: markup
                },
                callbacks: {
                    beforeOpen: function() {
                    
                        var target = this.ev,
                            typeClass = 'p-iframe-type-' + target.data( 'type' );
                            
                        this.contentContainer.addClass( typeClass );
                    }
                }
            });
        }
    };

    return component.init();

}());
