//////////////////
// Dependencies //
//////////////////
//	clientlib/scripts/vendorsclientlib/scripts/philips/jquery/jquery-1.10.1.min.js (or 2.0.2)
//	clientlib/scripts/philips/philips.js
//	clientlib/scripts/philips/libs/carousel.js


window.philips.components.aggregated.productDetailOutcomes = (function(){
	'use strict';
    
    /**
     * Namespace for Related Products & Services component.
     *
     * @namespace component
     * @private
     */
    var component = {
        
        /**
         * Stores the components used class names.
         *
         * @property            selectors
         * @memberof            component
         */
        selectors: {
            carousel: '.p-product-detail-outcomes .p-carousel'
        },
        
        /**
         * Kicks off component's initiation.
         * 
         * @method              init
         * @memberof            component
         * @returns {Object}    component
         */
        init: function() {
            
            this.carousel();

            return this;
        },
        
        /**
         * Facilitates the components carousel functionality.
         *
         * @method              carousel
         * @memberof            component
         */
        carousel: function() {
            
            var el = $( this.selectors.carousel );

            var options = {
                move: 1,
                maxItems: 1,
                minItems: 1,
                slideshow: false,
                animation: 'slide',
                selector: 'ul > li',
                animationLoop: false,
                namespace: 'p-carousel-',
                itemWidth: el.find( '> ul' ).width()
            };
            
            el.flexslider( options );
        }
    };
    
    return component.init();

}());
