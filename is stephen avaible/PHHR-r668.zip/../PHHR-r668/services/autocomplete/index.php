<?php
    echo file_get_contents( "autocomplete.json" );
?>