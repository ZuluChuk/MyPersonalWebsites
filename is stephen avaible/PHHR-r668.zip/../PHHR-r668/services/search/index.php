<?php

$include_dir = is_dir( '../../includes' ) ? '../../includes' : '../../services/search/includes';

// Get the request params
$request = $_POST;

// State params
$result_type    = $request[ 'result-type' ];
$limit          = (int) $request[ 'limit' ];
$offset         = (int) $request[ 'offset' ];
$total          = (int) $request[ 'total' ];
$moreResults    = $request[ 'moreResults' ] === 'true';

// Filter params
$term       = $request[ 'term' ];
$type       = $request[ 'type' ];
$sortby     = $request[ 'sortby' ];
$specialty  = $request[ 'specialty' ];

// Only stub out response for resource page
if ( $result_type !== 'resource') {
    echo json_encode( array() );
    return;
}

$new_offset = $moreResults ? $offset + $limit : $offset;
$html       = array();
$data       = array();


/*
HTML Sections
---------------------------*/
// Retrieve html snippets
$data[ 'request' ]          = $request; // Testing
$data[ 'facets' ]           = file_get_contents( "$include_dir/components/facets.html" );
$data[ 'specialty' ]        = file_get_contents( "$include_dir/components/select-specialty.html" );
$data[ 'statusHeading' ]    = file_get_contents( "$include_dir/components/status-heading.html" );
$data[ 'showMore' ]         = file_get_contents( "$include_dir/components/btn-more.html" );
$html[ 'resultFeatured' ]   = file_get_contents( "$include_dir/components/tile-search-feat.html" );
$html[ 'result' ]           = file_get_contents( "$include_dir/components/tile-search.html" );
$data[ 'results' ]          = array();

// Create results
$count = $moreResults ? $limit : $limit - 1;

// Add featured result to results array
if ( !$moreResults ) {    
    $data[ 'results' ] = array( $html[ 'resultFeatured' ] );
}

// Create the needed duplicates
for ( $i = 0; $i < $count; $i++ ) {
    array_push( $data[ 'results' ], $html[ 'result' ] );
}

// Concat results into string
$data[ 'results' ] = implode( "\n", $data[ 'results' ] );

// Update the status heading offset
$data[ 'statusHeading' ] = preg_replace_callback(

    '/(1([^\d][\sa-zA-Z])+)(\d+)/', 
    
    function( $matches ) {
        global $new_offset;
        return $matches[1] . $new_offset;
    },
    
    $data[ 'statusHeading' ]
);

// Update the button data
$button_patterns = array(
    '/(limit=")(\d)+(")/',
    '/(offset=")(\d)+(")/',
    '/(total=")(\d)+(")/',
    '/(term=")(\w|\s)+(")/'
);

$button_replacements = array(
    $limit,
    $new_offset,
    $total,
    $term
);

$data[ 'showMore' ] = preg_replace_callback(
    
    $button_patterns,
    
    function( $matches ) {
    
        global $button_patterns, $button_replacements;
    
        $result = $matches[1];
    
        foreach ( $button_patterns as $index => $pattern ) {
        
            if ( preg_match( $pattern, $matches[0] ) ) {
            
                $result = $matches[1] . $button_replacements[ $index ] . $matches[3];
            }
        }
    
        return $result;
    },
    
    $data[ 'showMore' ]
);


/*
State Object
---------------------------*/
// Setup state object
$data[ 'state' ] = array(
    'limit'         => $limit,
    'offset'        => $new_offset,
    'total'         => $total,
    'moreResults'   => $moreResults
);


/*
Output JSON
---------------------------*/
echo json_encode( $data );
