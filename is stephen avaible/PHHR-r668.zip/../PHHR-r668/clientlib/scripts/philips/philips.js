//////////////////
// Dependencies //
//////////////////
// None


/**
 * Top-level website namespace
 *
 * @namespace philips
 */
window.philips                       = window.philips || {};
window.philips.capabilities          = window.philips.capabilities || {};
window.philips.components            = window.philips.components || {};
window.philips.components.aggregated = window.philips.components.aggregated || {};
window.philips.components.atomic     = window.philips.components.atomic || {};
window.philips.libs                  = window.philips.libs || {};
window.philips.pages                 = window.philips.pages || {};
window.philips.responsive            = window.philips.responsive || {};
window.philips.templates             = window.philips.templates || {};
window.philips.utilities             = window.philips.utilities || {};

