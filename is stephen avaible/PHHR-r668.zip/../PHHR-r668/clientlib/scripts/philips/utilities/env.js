//////////////////
// Dependencies //
//////////////////
//  clientlib/scripts/philips/philips.js

window.philips.utilities.env = (function(){

    var html = $( 'html' );

    /**
     * Namespace for api.
     *
     * @namespace api
     * @private
     */
	var api = {

        /**
         * Test for IE9
         *
         * @memberof env
         * @return {Boolean}
         */
        isIE9: html.hasClass( 'ie9' ),

        /**
         * Test for IE8
         *
         * @memberof env
         * @return {Boolean}
         */
		isIE8: html.hasClass( 'ie8' ),

        /**
         * Test for Screen Width
         * @param  {[type]} number [takes any number]
         * @memberof env
         * @return {Boolean}
         */
        testMedia: function(value){
            return (window.matchMedia && matchMedia('only screen and (max-width: ' + value + 'px)').matches || (this.isIE9 && window.innerWidth < value));
        }
	};

    return api;

}());