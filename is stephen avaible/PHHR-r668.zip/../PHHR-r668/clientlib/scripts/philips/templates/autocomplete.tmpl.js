window.philips.templates.autocomplete = (function(
    
    hogan
    
){
    var template = '{{! autocomplete results template }}' + 
        '<ul>' +
        '{{#suggested}}' +
            '<li class="item">{{{.}}}</li>' +
        '{{/suggested}}' +
            '<li class="heading"><h4>Recommended Products</h4></li>' +
        '{{#recommended}}' +
            '<li class="item">{{{.}}}</li>' +
        '{{/recommended}}' +
            '<li class="heading"><h4>Featured Links</h4></li>' +        
        '{{#featured}}' +
            '<li class="item">' +
                '<a href="' + '{{url}}' + '"><div class="p-ac-featured">' +
                    '<img src="' + '{{figure}}' + '">' +
                    '<div>' +
                        '<h5>' + '{{title}}' + '</h5>' +
                        '<p>' + '{{description}}' + '</p>' +
                    '</div>' +
                '</div></a>' +
            '</li>' +
        '{{/featured}}' +
        '</ul>';
    return hogan.compile(template);
    
}(

window.Hogan

));