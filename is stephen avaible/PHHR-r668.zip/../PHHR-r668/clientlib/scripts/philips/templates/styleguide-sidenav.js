//////////////////
// Dependencies //
//	clientlib/scripts/philips/philips.js
//////////////////

window.philips.templates.styleguideSidenav =
	'<h1 class="sg-logo">Menu</h1>' +
	'<ul role="navigation">' +
		'{{#each sections}}' +
			'<li>' +
				'<h2>{{title}}</h2>' +
				'<ul>' +
					'{{#each subsections}}' +
						'<li><a href="#{{id}}" title="{{title}}">{{title}}</a></li>' +
					'{{/each}}' +
				'</ul>' +
			'</li>' +
		'{{/each}}' +
	'</ul>';