/**
 * Proxy for handling site wide events
 * @namespace
 * @fires resize
 **/
window.philips = window.philips || {};

window.philips.events = (function($){
    var
        $dispatcher = $({}),
        $document = $(document),
        $window = $(window),
        resizeTimer
        ;

    // extend the events with constants for custom events
    $dispatcher.extend({
        RESIZE: 'resize',
        LOAD: 'load',
        KEYDOWN: 'keydown',
        KEYUP: 'keyup',
        PICTUREFILL: 'picturefill'
    });

    $window.resize(handleResize);
    $window.load(handleLoad);
    $document.keydown(handleKeydown);
    $document.keyup(handleKeyup);
    window.picturefill.callback = handlePicturefill;

    /**
     * Handles resize event. Uses timeout to ensure responsive state event only
     * fires once per x millis.
     * @method
     * @private
     */
    function handleResize() {
        clearTimeout(resizeTimer);
        resizeTimer = setTimeout(function(){
            // todo: parse width and height with trigger
            $dispatcher.trigger($dispatcher.RESIZE);
        }, 30);
    }

    /**
     * Handles resize event.
     * @method
     * @private
     */
    function handleLoad(e){
        $dispatcher.trigger($dispatcher.LOAD,e);
    }

    var pressedKeys = [];

    /**
     * Handles keydown event.
     * @method
     * @private
     */
    function handleKeydown(e){
        var keyCode = e.keyCode;
        pressedKeys[keyCode] = true;
        $dispatcher.trigger($dispatcher.KEYDOWN,keyCode);
    }

    /**
     * Handles keyup event.
     * @method
     * @private
     */
    function handleKeyup(e){
        var keyCode = e.keyCode;
        pressedKeys[keyCode] = false;
        $dispatcher.trigger($dispatcher.KEYUP,keyCode);
    }

    /**
     * Picturefill callback function.
     * @method
     * @private
     */
    function handlePicturefill(){
        $dispatcher.trigger($dispatcher.PICTUREFILL);
    }

    return $dispatcher;
})(jQuery);