//////////////////
// Dependencies //
//////////////////
//	clientlib/scripts/vendorsclientlib/scripts/philips/jquery/jquery-1.10.1.min.js (or 2.0.2)
//	clientlib/scripts/philips/philips.js
//  clientlib/scripts/vendor/viewport.min.js
//	clientlib/scripts/philips/libs/carousel.js

window.philips.components.aggregated.eventsXL = (function(
    
    // Dependency arguments
    $,
    showDetail

){
	'use strict';

    /**
     * Namespace for Related Events component.
     *
     * @namespace component
     * @private
     */
    var component = {
        
        /**
         * Kicks off component's initiation.
         *
         * @method              init
         * @memberof            component
         * @returns {Object}    component
         */
        init: function() {
                        
            showDetail.create({
                noToggleAfter: 'vp-m',
                toggleContainer: '.p-event-schedule',
                toggler: 'h3',
                toggleClass: 'schedule-active'
            });

            return this;
        }
    };

    return component.init();

}(
    
    // Dependencies
    jQuery,
    window.philips.libs.showDetail

));