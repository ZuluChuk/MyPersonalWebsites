//////////////////
// Dependencies //
//////////////////
//	clientlib/scripts/vendorsclientlib/scripts/philips/jquery/jquery-1.10.1.min.js (or 2.0.2)
//	clientlib/scripts/philips/philips.js
//	clientlib/scripts/vendor/jquery/jquery.formparams.min.js
//  clientlib/scripts/vendor/jquery/jquery.magnific-popup.min.js

window.philips.components.aggregated.search = (function(
    
    // Dependency arguments
    $,
    globalVps,
    radioToggle,
    showDetail
    
) {
	'use strict';
    
    
    /**
     * Namespace for Search results component.
     *
     * @namespace component
     * @private
     */
    var component = {
        
        /**
         * Stores the css selectors used by the component.
         *
         * @property            selectors
         * @memberof            component
         */
        selectors: {
            context: '.p-search',
            forms: '.p-search-form',
            btnShowMore: '.p-search-more',
            narrowPanel: '.p-search-panel',
            videoCTA: '.p-video-still',
            
            // The following must map to the `this.sections` array
            facets: '.p-search-facets',
            specialty: '.p-search-specialty',
            statusHeading: '.p-status-heading',
            results: '.p-search-results',
            showMore: '.p-search-more-wrap'
        },
        
        /**
         * Stores the css class names used by the component.
         *
         * @property            classes
         * @memberof            component
         */
        classes: {
            narrowResults: 'p-search-narrow',
            narrowActive: 'p-narrow-active'
        },
        
        /**
         * Stores the sections to update. Values must map to keys in `this.selectors` and json response.
         * This array is converted to an object during `this.init`. Each index is used as a key with a jQuery dom object as its value.
         *
         * @property            sections
         * @memberof            component
         */
        sections: [
            'facets',
            'specialty',
            'statusHeading',
            'results',
            'showMore'
        ],
        
        /**
         * Kicks off component's initiation.
         * 
         * @method              init
         * @memberof            component
         * @returns {Object}    component
         */
        init: function() {
            
            this.context = $( this.selectors.context );
            this.forms = $( this.selectors.forms );
            this.service = this.forms[0].action;
            
            this.cacheSections();
            this.bind();
            radioToggle.create({
                
                radios: 'input[name=range]',
                radio: '.p-form-toggler',
                controls: '.p-form-toggle'
            });
            showDetail.create({
                
                noToggleAfter:'vp-m',
                toggleContainer: this.selectors.narrowPanel,
                toggler: this.classes.narrowResults,
                toggleClass: this.classes.narrowActive
            });

            return this;
        },
        
        /**
         * Cache each section to be updated.
         *
         * @method              cacheSections
         * @memberof            component
         */
        cacheSections: function() {
            
            var self = this,
                sections = {};
            
            $.each( this.sections, function( index, value ) {
                sections[ value ] = self.context.find( self.selectors[ value ] );
            });
            
            this.sections = sections;
        },
        
        /**
         * Bind the DOM events.
         *
         * @method              bind
         * @memberof            component
         */
        bind: function() {
            
            // Request search results
            this.forms.on( 'change', $.proxy( this, 'filter' ) );
            this.sections.showMore.on( 'click', 'button', $.proxy( this, 'showMore' ) );
            
            // Handle video modal
            this.videoModal();
            
        },
        
        /**
         * Gather form filter data
         *
         * @method              filter
         * @memberof            component
         */
        filter: function(e) {
            
            var data = {},
                returnData = e ? false : true;
            
            this.forms.each( function() {
                $.extend( data, $( this ).formParams() );
            });

            if ( returnData ) {
                return data;
            }
            
            $.extend( data, this.showMore() );

            this.sendRequest( data );
        },
        
        /**
         * Gather data "show more" action.
         *
         * @method              showMore
         * @memberof            component
         */
        showMore: function(e) {
            
            var showMore = e ? true : false,
                data = { moreResults: showMore },
                btnData = this.sections.showMore.find( this.selectors.btnShowMore ).data();
            
            $.extend( data, btnData );
            
            if ( !showMore ) {
                
                // reset the offset to the default limit
                data.offset = data.limit;
                
                return data;
            }
            
            $.extend( data, this.filter(), btnData );

            this.sendRequest( data );
        },
        
        /**
         * Creates a modal to hold the video player.
         *
         * @method              videoModal
         * @memberof            component
         */
        videoModal: function() {

            this.context.magnificPopup({
                type: 'image',
                delegate: this.selectors.videoCTA,
                callbacks: {
                    elementParse: function( state ) {
                        state.src = state.el.data( 'video-src' );
                    }
                }
            });
        },
        
        /**
         * Request results from server.
         *
         * @method              sendRequest
         * @memberof            component
         */
        sendRequest: function( data ) {
            
            $.ajax({
                url: this.service,
                type: 'POST',
                dataType: 'json',
                data: data,
                context: this,
                success: this.update,
                error: this.error
            });
        },
        
        /**
         * Update the page with response data
         *
         * @method              update
         * @memberof            component
         */
        update: function( data ) {
            
            var action,
                appendResults,
                self = this;
            
            if ( !data.results ) {
                return;
            }
            
            appendResults = data.state.moreResults;
            
            $.each( this.sections, function( key ) {
                
                action = ( key === 'results' && appendResults ) ? 'append' : 'html';
                
                self.sections[ key ][ action ]( data[ key ] );
            });
        },
        
        /**
         * Handle request errors
         *
         * @method              error
         * @memberof            component
         */
        error: function() {
            
            console.log( 'error:', arguments );
        }
        
    };
    
    return component.init();
        
}(
    // Dependencies
    jQuery,
    window.philips.responsive.viewports,
    window.philips.libs.radioToggle,
    window.philips.libs.showDetail
));
