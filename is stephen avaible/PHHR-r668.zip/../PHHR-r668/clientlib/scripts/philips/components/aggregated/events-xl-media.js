//////////////////
// Dependencies //
//////////////////
//	clientlib/scripts/vendorsclientlib/scripts/philips/jquery/jquery-1.10.1.min.js (or 2.0.2)
//	clientlib/scripts/philips/philips.js
//  clientlib/scripts/vendor/pubsub.js
//	clientlib/scripts/philips/libs/carousel.js

window.philips.components.aggregated.productDetailGallery = (function(

    // Dependency arguments
    $,
    carousel,
    globalVps
    
) {
	'use strict';

    /**
     * Namespace for Related Products & Services component.
     *
     * @namespace component
     * @private
     */
    var component = {
        
        /**
         * Stores the pubsub channel names.
         *
         * @property            channels
         * @memberof            component
         */
        channel: {
            videos: {
                select: 'events/event/videos'
            }
        },
        
        /**
         * Stores the components used class names.
         *
         * @property            selectors
         * @memberof            component
         */
        selectors: {
            context: '.p-event-media',
            carousel: '.p-events-event-channels.p-carousel',
            videoThumb: '.p-grid li',
            videoContent: '.p-event-media-card',
            activeSibling: '.p-active',
            activeClass: 'p-active',
            inactiveClass: 'p-inactive-media',
            showMoreContent: '.p-media-show-more'
        },
        
        html: {
            showMoreContent: '<button type="button" class="p-media-show-more">View More Videos</button>'
        },
        
        /**
         * Kicks off component's initiation.
         * 
         * @method              init
         * @memberof            component
         * @returns {Object}    component
         */
        init: function() {
            
            this.context = $( this.selectors.context );
            this.carousel = this.context.find( this.selectors.carousel );
            this.videoContent = this.context.find( this.selectors.videoContent );
            this.btnMoreMedia = this.context.find('.p-grid li:nth-child(n+7)');
            
            this.bind();
            this.initCarousel();
            this.initMoreContent();

            return this;
        },
        
        /**
         * Bind event listeners.
         * 
         * @method              bind
         * @memberof            component
         */
        bind: function() {
            
            this.carousel.on( 'click', this.selectors.videoThumb, $.proxy( this, 'update' ) );
            this.context.on( 'click', this.selectors.showMoreContent, $.proxy( this, 'showMoreContent' ) );   
        },
        
        /**
         * Facilitates the components carousel functionality.
         *
         * @method              initCarousel
         * @memberof            component
         */
        initCarousel: function() {
            
            if ( globalVps.matches( 'vp-m' ) ) {
                
                carousel.create( this.carousel, {
                    move: 6,
                    maxItems: 6,
                    minItems: 6,
                    controlNav: false
                });
            }
        },
        
        /**
         * Initializes all media past n = 6 to inactive in medium vp.
         *
         * @method              initMoreContent
         * @memberof            component
         */
        initMoreContent: function() {
                
            if ( globalVps.matches( 'vp-m' ) ) {
                return;
            }
            
            this.btnMoreMedia.toggleClass( this.selectors.inactiveClass );
            
            this.context.append( this.html.showMoreContent );
        },
        
        /**
         * Facilitates showing more media content
         *
         * @method              showMoreContent
         * @memberof            component
         */
        showMoreContent: function( e ) {
            
            var target = $( e.currentTarget );
            
            e.preventDefault();
            
            target.remove();
            
            this.btnMoreMedia.toggleClass( this.selectors.inactiveClass );
        },
        
        /**
         * Facilitates updating the media content.
         *
         * @method              update
         * @memberof            component
         */
        update: function( e ) {
            
            var target = $( e.currentTarget ),
                src = target.data( 'src' ),
                sibling = target.siblings( this.selectors.activeSibling );
            
            if ( target.hasClass( this.selectors.activeClass ) ) {
                return;
            }

            sibling.toggleClass( this.selectors.activeClass );
            target.toggleClass( this.selectors.activeClass );
            this.switchContent( src );
        },
        /**
         * Facilitates switching out of media content.
         *
         * @method              update
         * @memberof            component
         */
        switchContent: function( src ) {
            
            var self = this;
                       
            $.ajax({
                url: src,
                success: function( data ) {

                    self.videoContent.html( data );
                    window.picturefill();
                },
                error: function() {
                    
                    console.log( arguments );
                }
            });
        }
    };
    
    return component.init();

}(
    // Dependencies
    jQuery,
    window.philips.libs.carousel,
    window.philips.responsive.viewports
    
));
