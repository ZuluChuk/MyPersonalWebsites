//////////////////
// Dependencies //
//////////////////
//	clientlib/scripts/vendorsclientlib/scripts/philips/jquery/jquery-1.10.1.min.js (or 2.0.2)
//	clientlib/scripts/philips/philips.js
//  clientlib/scripts/vendor/viewport.min.js
//	clientlib/scripts/philips/libs/carousel.js

window.philips.components.aggregated.eventsSpeakers = (function(
    
    // Dependency arguments
    $,
    viewport,
    carousel

){
	'use strict';

    /**
     * Namespace for Events Speakers
     *
     * @namespace component
     * @private
     */
    var component = {

        selectors: {
            context: '.p-event-speakers',
            carousel: '.p-carousel',
            tile: '.p-tile',
            parentClick: '.p-event-speakers ul',
            clickTile: '.p-tile-speaker'
        },
        
        /**
         * Kicks off component's initiation.
         *
         * @method              init
         * @memberof            component
         * @returns {Object}    component
         */
        init: function() {
            
            this.context = $( this.selectors.context );
            this.parentContext = $( this.selectors.parentClick );
            
            this.configViewports();
            this.videoModal();
            
            if ( this.viewports.is( 'one' ) ) {
                return;
            }
            
            this.configCarousel();
            this.normalizeItemHeight();
            
            return this;
        },
        
        /**
         * Creates a modal to hold the video player.
         * Generates magnificPopup for tile onclick. 
         *
         * @method              videoModal
         * @memberof            component
         */
        videoModal: function() {
            
            var items = this.context.find( this.selectors.clickTile );
            
            items.magnificPopup( {
                
                type: 'inline',
                callbacks: {
                    elementParse: function( state ) {
                        
                        state.src = state.el.clone();
                    }
                }
            });
        },
        
        /**
         * Configure optimal viewport sizes. Global viewports don't align well.
         * Viewports are named by the number of tiles they should show.
         *
         * @method              viewports
         * @memberof            component
         * @returns {Object}    component
         */
        configViewports: function() {
            
            var vps = [
                {
                    name: 'one',
                    width: [ 0, 518 ]
                },
                {
                    name: 'three',
                    width: [ 519 ]
                }
            ];
            
            this.viewports = viewport( vps );
        },
        
        /**
         * Facilitates the components carousel.
         *
         * @method              carousel
         * @memberof            component
         */
        configCarousel: function() {

            var el = this.context.find( this.selectors.carousel );
            
            carousel.create( el, {
                minItems: 3,
                maxItems: 3
            });
        },
        
        /**
         * Normalizes the heights of each item in the carousel.
         *
         * @method              normalizeItemHeight
         * @memberof            component
         */
        normalizeItemHeight: function() {
            
            window.philips.libs.fixedRowHeight.create(
                this.selectors.context,
                this.selectors.tile
            );
        }
    };

    return component.init();

}(
    
    // Dependencies
    jQuery,
    window.viewport,
    window.philips.libs.carousel

));