//////////////////
// Dependencies //
//////////////////
//  clientlib/scripts/vendorsclientlib/scripts/philips/jquery/jquery-1.10.1.min.js (or 2.0.2)
//  clientlib/scripts/philips/philips.js
//  clientlib/scripts/vendor/jquery/jquery.magnific-popup.min.js

window.philips.components.aggregated.calloutVideo = (function() {
    'use strict';

    var module = {
        
        /**
         * Stores the module's used class names.
         *
         * @property selectors
         * @memberof module
         */
        selectors: {
            cta: '.p-video-image a, .cta'
        },

        /**
         * Kicks off module's initiation.
         *
         * @method init
         * @memberof module
         * @param {Object} A jQuery element representing the context of the module.
         * @returns {Object} module
         */
        init: function( context ) {

            this.context = context;

            this.videoModal();
        },
        
        /**
         * Creates a modal to hold the video player.
         *
         * @todo Placehodler until video player is ready.
         * @method  videoModal
         * @memberof module
         */
        videoModal: function() {

            var el = this.context.find( this.selectors.cta );

            el.magnificPopup({
                type: 'ajax',
                closeOnBgClick: false
            });
        }
    };
    
    return function( context ) {
        module.init( context );
    };

}());
