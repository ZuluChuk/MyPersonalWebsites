//////////////////
// Dependencies //
//////////////////
//	clientlib/scripts/vendorsclientlib/scripts/philips/jquery/jquery-1.10.1.min.js (or 2.0.2)
//	clientlib/scripts/philips/philips.js
//  clientlib/scripts/vendor/viewport.min.js
//	clientlib/scripts/philips/libs/carousel.js

window.philips.components.aggregated.altTopicOther = (function(
    
    // Dependency arguments
    $,
    viewport,
    carousel

){
	'use strict';

    /**
     * Namespace for Related Products & Services component.
     *
     * @namespace component
     * @private
     */
    var component = {

        selectors: {
            context: '.p-alt-topics-other',
            carousel: '.p-carousel',
            tile: '.p-tile'
        },
        
        /**
         * Kicks off component's initiation.
         *
         * @method              init
         * @memberof            component
         * @returns {Object}    component
         */
        init: function() {
            
            this.context = $( this.selectors.context );
            
            this.configViewports();
            this.configCarousel();
            this.normalizeItemHeight();

            return this;
        },
        
        /**
         * Configure optimal viewport sizes. Global viewports don't align well.
         * Viewports are named by the number of tiles they should show.
         *
         * @method              viewports
         * @memberof            component
         * @returns {Object}    component
         */
        configViewports: function() {
            
            var vps = [
                {
                    name: 'one',
                    width: [ 0, 518 ]
                },
                {
                    name: 'three',
                    width: [ 519 ]
                }
            ];
            
            this.viewports = viewport( vps );
        },
        
        /**
         * Facilitates the components carousel.
         *
         * @method              carousel
         * @memberof            component
         */
        configCarousel: function() {

            var slider,
                vps = this.viewports,
                items = vps.is( 'one' ) ? 1 : 3,
                el = this.context.find( this.selectors.carousel );
            
            slider = carousel.create( el, {
                minItems: items,
                maxItems: items,
                resize: function() {
                    
                    var items = vps.is( 'one' ) ? 1 : 3;
                
                    slider.vars.minItems = items;
                    slider.vars.maxItems = items;
                }
            });
        },
        
        /**
         * Normalizes the heights of each item in the carousel.
         *
         * @method              normalizeItemHeight
         * @memberof            component
         */
        normalizeItemHeight: function() {
            
            window.philips.libs.fixedRowHeight.create(
                this.selectors.context,
                this.selectors.tile
            );
        }
    };

    return component.init();

}(
    
    // Dependencies
    jQuery,
    window.viewport,
    window.philips.libs.carousel

));