//////////////////
// Dependencies //
//////////////////
//  clientlib/scripts/philips/vendor/jquery/jquery-1.10.1.min.js (or 2.0.2)
//  clientlib/scripts/philips/philips.js

window.philips.components.aggregated.homeTile = (function(
    
    // Dependency Arguments
    $
    
) {
    'use strict';
        
    /**
     * Namespace for the tiles section on Home.
     *
     * @namespace component
     * @private
     */
    var component = {
        
        /**
         * Stores the component's various states.
         *
         * @memberof            component
         */
        activeArticle: null,
        activeOverlay: null,
        curtainInit: false,
        
        /**
         * Stores the component's various selectors.
         *
         * @property            selectors
         * @memberof            component
         */
        selectors: {
            context: '.ph-home-tile',
            article: '.p-object',
            attrOverlay: '.p-article-overlay',
            overlay: '.p-overlay',
            cta: '.cta',
            parentFlag: '.p-grid-item',
            btnClose: '.p-close'
        },
        
        /**
         * Stores the component's various class names.
         *
         * @property            classes
         * @memberof            component
         */
        classes: {
            active: 'active',
            curtain: 'p-curtain',
            curtainActive: 'p-curtain-active',
            attrOverlay: 'p-article-overlay',
            overlay: 'p-overlay'           
        },

        /**
         * Kicks off component's initiation.
         *
         * @method              init
         * @memberof            component
         * @returns {Object}    component
         */
        init: function() {
            
            this.body = $( 'body' );
            this.context = $( this.selectors.context );
            
            this.bind();

            return this;
        },
        
        /**
         * Bind the DOM events.
         *
         * @method              bind
         * @memberof            component
         */
        bind: function() {
            
            var self = this.context;
            
            self.on('click', $.proxy(this, 'articleHandler'));

        },
        
        /**
         * Handle whether to open/close an overlay, or update url href.
         *
         * @method              articleHandler
         * @memberof            component
         */
        articleHandler: function(e) {
            
            var href,
                isClose,
                self = this,
                target = $(e.target),
                article = target.parents( this.selectors.article ),
                isOverlay = article.length ? article.hasClass( this.classes.attrOverlay ) : false;
            
            
            isClose = (function() {
                
                var isButton = target.is( self.selectors.btnClose ),
                    isActive = self.activeArticle,
                    isOverlayChild = target.parents( self.selectors.overlay ).length;
                    
                return isButton || ( isActive && !isOverlayChild );
            }());

            if ( isClose ) {
                
                this.handleOverlay();
            }            
            else if ( isOverlay ) {
                
                this.activeArticle = article;
                this.activeOverlay = article.find( this.selectors.overlay );
                
                this.handleOverlay( article );                
            }            
            else {
                
                href = article.find( this.selectors.cta ).get(0).href;

                this.handleCta( href );
            }
        },
        
        /**
         * Update url href
         *
         * @method              handleCta
         * @memberof            component
         */
        handleCta: function( cta ) {
            window.location.href = cta;
        },
        
        /**
         * Open/close overlays
         *
         * @method              handleOverlay
         * @memberof            component
         */
        handleOverlay: function( article ) {
            
            var active = this.classes.active,
                isClose = !article;
            
            this.addCurtain();
                        
            if ( isClose ) {
                
                this.activeOverlay.hide();
                this.getMask( this.activeArticle ).removeClass( active );
                this.body.removeClass( this.classes.curtainActive );
                
                this.activeArticle = null;
                this.activeOverlay = null;
                
                return;
            }

            this.activeArticle = article;
            this.activeOverlay = article.find( this.selectors.overlay );
            
            this.activeOverlay.fadeIn();
            this.getMask( article ).addClass( active );
            this.body.addClass( this.classes.curtainActive );
            
        },
        
        /**
         * Determine which element is the root tile wrapper.
         *
         * @method              handleCta
         * @memberof            component
         */
        getMask: function( article ) {
            
            if ( article.parent().is( this.selectors.parentFlag ) ) {
                return article;
            }
            else {
                return article.children(':first-child');
            }
        },
        
        /**
         * Show a blocking curtain when an overlay is open.
         *
         * @method              addCurtain
         * @memberof            component
         */
        addCurtain: function() {
            
            var articles;
            
            if ( this.curtainInit ) {
                return;
            }
            
            articles = this.context.find( this.selectors.article );
            
            articles.append( '<div class="' + this.classes.curtain + '" />' );
            
            this.curtainInit = true;
        }

    };

    return component.init();

}(
    // Dependencies
    jQuery
));