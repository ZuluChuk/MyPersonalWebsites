//////////////////
// Dependencies //
//////////////////
//	clientlib/scripts/vendorsclientlib/scripts/philips/jquery/jquery-1.10.1.min.js (or 2.0.2)
//	clientlib/scripts/philips/philips.js
//  clientlib/scripts/vendor/jquery/jquery.magnific-popup.min.js

window.philips.components.aggregated.eventsXLFindUs = (function(
    
    // Dependency arguments
    $

){
	'use strict';

    /**
     * Namespace for Related Events component.
     *
     * @namespace component
     * @private
     */
    var component = {

        selectors: {
            context: '.p-event-xl-map',
            maps: '.p-event-map-sml a'
        },
        
        /**
         * Kicks off component's initiation.
         *
         * @method              init
         * @memberof            component
         * @returns {Object}    component
         */
        init: function() {
            
            this.context = $( this.selectors.context );

            this.modal();
            
            return this;
        },
        
        /**
         * Creates a modal showing a larger image.
         *
         * @method  modal
         * @memberof component
         */
        modal: function() {

            var maps = this.context.find( this.selectors.maps );

            maps.magnificPopup({
                type:'image'
            });
        }
        
    };

    return component.init();

}(
    
    // Dependencies
    jQuery

));