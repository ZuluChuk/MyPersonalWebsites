//////////////////
// Dependencies //
//////////////////
//	clientlib/scripts/vendorsclientlib/scripts/philips/jquery/jquery-1.10.1.min.js (or 2.0.2)
//	clientlib/scripts/philips/philips.js
//  clientlib/scripts/vendor/viewport.min.js
//	clientlib/scripts/philips/libs/carousel.js

window.philips.components.aggregated.eventsRelated = (function(
    
    // Dependency arguments
    $,
    viewport,
    carousel

){
	'use strict';

    /**
     * Namespace for Related Events component.
     *
     * @namespace component
     * @private
     */
    var component = {

        selectors: {
            context: '.p-event-related',
            carousel: '.p-carousel',
            tile: '.p-tile'
        },
        
        /**
         * Kicks off component's initiation.
         *
         * @method              init
         * @memberof            component
         * @returns {Object}    component
         */
        init: function() {
            
            this.context = $( this.selectors.context );
            
            this.configViewports();
            
            if ( this.viewports.is( 'one' ) ) {
                return;
            }
            
            this.configCarousel();
            this.normalizeItemHeight();

            return this;
        },
        
        /**
         * Configure optimal viewport sizes. Global viewports don't align well.
         * Viewports are named by the number of tiles they should show.
         *
         * @method              viewports
         * @memberof            component
         * @returns {Object}    component
         */
        configViewports: function() {
            
            var vps = [
                {
                    name: 'one',
                    width: [ 0, 518 ]
                },
                {
                    name: 'three',
                    width: [ 519 ]
                }
            ];
            
            this.viewports = viewport( vps );
        },
        
        /**
         * Facilitates the components carousel.
         *
         * @method              carousel
         * @memberof            component
         */
        configCarousel: function() {

            var el = this.context.find( this.selectors.carousel );
            
            carousel.create( el, {
                minItems: 3,
                maxItems: 3
            });
        },
        
        /**
         * Normalizes the heights of each item in the carousel.
         *
         * @method              normalizeItemHeight
         * @memberof            component
         */
        normalizeItemHeight: function() {
            
            window.philips.libs.fixedRowHeight.create(
                this.selectors.context,
                this.selectors.tile
            );
        }
    };

    return component.init();

}(
    
    // Dependencies
    jQuery,
    window.viewport,
    window.philips.libs.carousel

));