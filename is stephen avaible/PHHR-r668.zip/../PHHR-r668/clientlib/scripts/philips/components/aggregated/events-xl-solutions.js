//////////////////
// Dependencies //
//////////////////
//	clientlib/scripts/vendorsclientlib/scripts/philips/jquery/jquery-1.10.1.min.js (or 2.0.2)
//	clientlib/scripts/philips/philips.js
//  clientlib/scripts/vendor/jquery/jquery.magnific-popup.min.js

window.philips.components.aggregated.eventsXLSolutions = (function(
    
    // Dependency arguments
    $,
    philips,
    carousel

){
	'use strict';

    /**
     * Namespace for Related Events component.
     *
     * @namespace component
     * @private
     */
    var component = {

        selectors: {
            context: '.p-events-solutions',
            carousel: '.p-carousel',
            tile: '.p-tile-solution',
            maps: '.p-tile-image a'
        },
        
        /**
         * Kicks off component's initiation.
         *
         * @method              init
         * @memberof            component
         * @returns {Object}    component
         */
        init: function() {
            
            this.tile = $( this.selectors.tile );
            this.context = $( this.selectors.context );
            
            this.configCarousel();
            this.modal();
            
            return this;
        },
        
        /**
         * Facilitates the components carousel.
         *
         * @method              carousel
         * @memberof            component
         */
        configCarousel: function() {

            var el = this.context.find( this.selectors.carousel );
            
            carousel.create( el );
        },
        
        /**
         * Creates a modal showing a larger image.
         *
         * @method  modal
         * @memberof component
         */
        modal: function() {

            var maps = this.tile.find( this.selectors.maps );

            maps.magnificPopup({
                type:'image'
            });
        }
        
    };

    return component.init();

}(
    
    // Dependencies
    jQuery,
    window.philips,
    window.philips.libs.carousel

));