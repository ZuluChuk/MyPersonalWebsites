//////////////////
// Dependencies //
//////////////////
//  clientlib/scripts/vendorsclientlib/scripts/philips/jquery/jquery-1.10.1.min.js (or 2.0.2)
//  clientlib/scripts/philips/philips.js
//  clientlib/scripts/vendor/jquery/jquery.magnific-popup.min.js

window.philips.components.aggregated.productDetailHero = (function(
    
    // Dependency Arguments
    $
){
    'use strict';

    /**
     * Namespace for Product Detail Hero component.
     *
     * @namespace component
     * @private
     */
    var component = {
        
        /**
         * Stores the components used class names.
         *
         * @property            selectors
         * @memberof            component
         */
        selectors: {
            section: '.p-product-detail-hero',
            cta: '.cta',
            videoCTA: '.p-video-play-arrow, .p-video-still'
        },

        /**
         * Kicks off component's initiation.
         *
         * @method              init
         * @memberof            component
         * @returns {Object}    component
         */
        init: function() {

            this.context = $( this.selectors.section );

            this.videoModal();
            this.moreInfo();

            return this;
        },
        
        /**
         * Creates a modal to hold the video player.
         *
         * @method              videoModal
         * @memberof            component
         */
        videoModal: function() {

            var el = this.context.find( this.selectors.videoCTA );

            el.magnificPopup({
                items: {
                    src: 'clientlib/images/fpo/video.jpg'
                },
                type: 'image'
            });
        },
        
        /**
         * Creates a modal to show more info for the selected CTA.
         *
         * @method              moreInfo
         * @memberof            component
         */
        moreInfo: function() {

            var el = this.context.find( this.selectors.cta );
            
            var markup = [
                '<div class="p-iframe">',
                '<div class="mfp-close"></div>',
                '<iframe class="mfp-iframe" frameborder="0" allowfullscreen></iframe>',
                '</div>'
            ].join('');
            
            el.each( function( i, item ) {
                
                $( item ).magnificPopup({
                    type: 'iframe',
                    iframe: {
                        markup: markup
                    },
                    callbacks: {
                        beforeOpen: function() {
                        
                            var target = this.ev,
                                typeClass = 'p-iframe-type-' + target.data( 'type' );
                                
                            this.contentContainer.addClass( typeClass );
                        }
                    }
                });
            });
        }
    };

    return component.init();

}(
    // Dependencies
    jQuery
));
