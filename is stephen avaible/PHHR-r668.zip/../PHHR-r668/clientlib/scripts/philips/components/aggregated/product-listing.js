//////////////////
// Dependencies //
//////////////////
//	clientlib/scripts/vendor/jquery/jquery-1.10.1.min.js (or 2.0.2)
//	clientlib/scripts/vendor/jquery/jquery.scrollto.js
//	clientlib/scripts/vendor/jquery/jquery.easing.min.js
//	clientlib/scripts/vendor/images-loaded.js
//	clientlib/scripts/philips/philips.js
//	clientlib/scripts/philips/libs/fixed-row-height.js



/////////////////////
// Tightly Coupled //
/////////////////////
// In deciding how to handle product category display, the choice was between server-side generation with the DOM as the source of record,
// and client-side templating with product information in memory. For the purposes of SEO, Content Management, and reduction of client-server interactions,
// the decision was made to have the server populate the DOM with all product info on page load, and to manipulate it via JavaScript, rather than constructing
// the markup dynamically with a JavaScript object as the backing model.
//
// The big downside of this approach is that this script is tightly coupled to the HTML. Required class names, data attributes, and relational hierarchies should
// be captured here to clearly document these dependencies.
//
// 1. Class names, both those referenced from the HTML and those dynamically applied by this script, are listed in the "selectors" and "classNames" module properties, below.
// 2. Relational Hierarchies:
//    a. listingComponent is the root element of this module, and serves as selector context for familyTiles and listingHeading
//    b. familyTiles is a collection of grid tiles that represent product categories; each serves as selector context for familyHeading elements, and productTileContainer
//    elements are found adjacent (subsequent) to these nodes
//    c. productTileContainer elements are used as selector context for each productTileSet
//    d. Each seeAllLink obtains a refernece to its nearest ancestor familyTileGridItem element
//    e. familyTileGridItem is the selector context for the productTileContainer associated with a clicked seeAllLink element

window.philips.components.aggregated.productListing = (function(
    
    // Dependency Arguments
    $,
    env

){
	'use strict';

	/**
	 * Namespace for functions relating to filtering and display of product tiles, as well as displaying product count values
	 *
	 * @namespace productListing
	 * @private
	 */
	var productListing = {
		'selectors': {
			'listingComponent'     : '.p-product-listing',
			'listingHeading'       : 'h1.p-product-heading',
			'familyTiles'          : '.p-product-family-tile',
			'singleProductTiles'   : '.p-single-product-tile',
			'allTiles'             : '.p-product-family-tile, .p-single-product-tile',
			'seeAllLinks'          : '.p-product-family-tile > button',
			'familyHeading'        : '.p-product-heading',
			'productTileContainer' : '.p-product-tiles',
			'productTileSet'       : '.p-product-tile-set > li',
			'productTiles'         : '.p-product-tile',
			'filterSelect'         : '#filter-products-by',
			'specialtyDataAttr'    : 'data-filter-specialty',
			'familyTileGrid'       : '.p-product-family-tiles',
			'familyTileGridItem'   : '.p-product-family-tiles > li',
			'tileNotProductList'   : ':not(.p-is-product-list-active):not(.p-is-product-filtered-out)',
			'productPanelClose'    : '.p-product-tiles-panel-close',
			'activeProductsHeading': '.p-is-product-list-active .p-product-tiles-header .p-product-heading'
		},
		'classNames': {
			'componentReady'   : 'p-product-list-ready',
			'tileActive'       : 'p-is-product-tile-active',
			'filteredOut'      : 'p-is-product-filtered-out',
			'activeProducts'   : 'p-is-product-list-active',
			'firstColActive'   : 'p-is-first-col-active',
			'secondColActive'  : 'p-is-second-col-active',
			'thirdColActive'   : 'p-is-third-col-active'
		},
		'nodes': {
			'gridListItemWrapper': '<li class="p-grid-item p-xs-one-whole"></li>'
		},
		'timer': null,

		/**
		 * Kicks off event delegation and population of initial product count values
		 * @method				setup
		 * @memberof			productListing
		 * @returns {Object}	productListing
		 */
		'setup': function(){
			this.elem              = $(this.selectors.listingComponent);
			this.listingHeading    = this.elem.find(this.selectors.listingHeading);
			this.familyTiles       = this.elem.find(this.selectors.familyTiles);
			this.productTotal      = 0;
			this.activeSpecialty   = 'all';
			this.productTileBuffer = null;

			this.attachEvents();
			this.updateProductCountsAndReturnEmpty();

			// Add a class to indicate that the component is ready, which will toggle some display values
			this.elem.addClass(this.classNames.componentReady);
			return this;
		},

		/**
		 * [description]
		 * @fires		productListing#handleResize, productListing#handleFamilyTileClick, productListing#handleFilterChange
		 * @method		attachEvents
		 */
		'attachEvents': function(){
			var context = this;

			if(window.matchMedia || env.isIE9){
				$(window).on('resize.productListing orientationchange.productListing', function(){
					context.handleResize();
				});
			}
			this.elem.on('click.productListing', this.selectors.familyTiles, function(e){
				if($(this).closest('.' + context.classNames.tileActive).length === 0){
					context.handleSeeAllClick(e);
				}
			});
			this.elem.on('change.productListing', this.selectors.filterSelect, function(e){
				context.handleFilterChange(e);
			});
			this.elem.on('click.productListing', this.selectors.productPanelClose, function(e){
				context.handlePanelCloseClick(e);
			});
		},

		/**
		 * [ description]
		 * @method		handlePanelClose
		 */
		'handlePanelCloseClick': function(e){
			var activeProductPanel = $('.' + this.classNames.activeProducts);
			e.preventDefault();

			this.closeProductPanel(activeProductPanel);
		},

		/**
		 * [description]
		 * @method		handleResize
		 */
		'handleResize': function(){
			var context = this;

			window.clearTimeout(context.timer);
			context.timer = window.setTimeout(function(){

				var familyTileGridItem   = $('.' + context.classNames.tileActive),
					productTileContainer = $('.' + context.classNames.activeProducts);

				if(productTileContainer.length){
					context.placeProductTiles(familyTileGridItem, productTileContainer);
				}

			}, 1000);
		},

		/**
		 * [description]
		 * @param {Object} e	jQuery event object
		 * @method				handleSeeAllClick
		 */
		'handleSeeAllClick': function(e){
			var productFamilyTile      = $(e.target),
				activeProductsClass    = this.classNames.activeProducts,
				familyTileGridItem     = productFamilyTile.closest(this.selectors.familyTileGridItem),
				tileActiveClass        = this.classNames.tileActive,
				currentProductList     = $('.' + activeProductsClass),
				productTileBuffer;

			e.preventDefault();

			// Close any open panel
			this.closeProductPanel(currentProductList);

			// Get the related set of product tiles, wrapped in a container for insertion
			productTileBuffer = this.getProductTileBuffer(familyTileGridItem);

			// Insert the panel into the DOM
			this.placeProductTiles(familyTileGridItem, productTileBuffer);

			// Animate the height of the panel to display it
			this.openProductPanel(productTileBuffer);

			familyTileGridItem.addClass(tileActiveClass);

			window.philips.libs.fixedRowHeight.create('.' + activeProductsClass, this.selectors.productTiles);
		},

		/**
		 * [ description]
		 * @return {[type]} [description]
		 */
		'openProductPanel': function(productPanel){
			var productPanelHeight = productPanel.children().outerHeight(),
				timer;

			productPanel.animate(
				{'height': productPanelHeight + 'px'},
				600,
				'easeInOutQuad',
				function(){
					productPanel.height('auto');
				}
			);

			timer = window.setTimeout(function(){
				$.scrollTo(
					productPanel,
					600
				);
			}, 400);
		},

		/**
		 * [ description]
		 * @return {[type]} [description]
		 */
		'closeProductPanel': function(productPanel){
			var tileActiveClass = this.classNames.tileActive;

			$('.' + tileActiveClass).removeClass(tileActiveClass);

			productPanel.animate(
				{'height': '0px'},
				400,
				'easeInOutQuad',
				function(){
					productPanel.remove();
				}
			);
		},

		/**
		 * Takes a family tile and returns a related product tile set, prepped for insertion
		 * @param  {Object} familyTileGridItem		Newly active family tile (containing the clicked "See All" link), in a jQuery object
		 * @return {Object}							Set of product tiles associated with the active family tile, wrapped in a container and in a jQuery object
		 */
		'getProductTileBuffer': function(familyTileGridItem){
			var gridListItemWrapper = $(this.nodes.gridListItemWrapper),
				productTileContainer = familyTileGridItem.find(this.selectors.productTileContainer);

			gridListItemWrapper.height('0px');

			gridListItemWrapper.html(productTileContainer.clone(true));

			gridListItemWrapper.addClass(this.classNames.activeProducts);

			return gridListItemWrapper;
		},

		'doNodeInsert': function(familyTileGridItem, productTileContainer, places){
			var currentNode = familyTileGridItem,
				nextNode, i;

			for(i = 0; i < places; i++){
				nextNode = currentNode.nextAll(this.selectors.tileNotProductList).eq(0);
				currentNode = nextNode.length ? nextNode : currentNode;
			}
			currentNode.after(productTileContainer);
		},

		/**
		 * Layout columns depending on column number 
		 * @param  {[type]} description [description]
		 * @return {[type]}                      [description]
		 */
		'switchTwoColumn' : function(index, familyTileGridItem, productTileContainer){
			// Two column layout
			if(index % 2 === 1){
				familyTileGridItem.addClass(this.classNames.secondColActive);
				this.doNodeInsert(familyTileGridItem, productTileContainer, 0);
			}else{
				familyTileGridItem.addClass(this.classNames.firstColActive);
				this.doNodeInsert(familyTileGridItem, productTileContainer, 1);
			}
		},

		/**
		 * Adds classes depending on position of column 
		 * @param  {[type]} description [description]
		 * @return {[type]}                      [description]
		 */
		'switchThreeColumn' : function(index, familyTileGridItem, productTileContainer){
			switch(index % 3){
			case 0:
				familyTileGridItem.addClass(this.classNames.firstColActive);
				this.doNodeInsert(familyTileGridItem, productTileContainer, 2);
				break;
			case 1:
				familyTileGridItem.addClass(this.classNames.secondColActive);
				this.doNodeInsert(familyTileGridItem, productTileContainer, 1);
				break;
			case 2:
				familyTileGridItem.addClass(this.classNames.thirdColActive);
				this.doNodeInsert(familyTileGridItem, productTileContainer, 0);
				break;
			default :
				console.log('Solar Reported Bugfix: Unexpected value during layout');
				break;
			}
		},

		/**
		 * [ description]
		 * @param  {[type]} productTileContainer [description]
		 * @return {[type]}                      [description]
		 */
		'placeProductTiles': function(familyTileGridItem, productTileContainer){
			var tileNotProductList     = this.selectors.tileNotProductList,
				index                  = familyTileGridItem.prevAll(tileNotProductList).length,
				allActiveClasses       = this.classNames.firstColActive + ' ' + this.classNames.secondColActive + ' ' + this.classNames.thirdColActive;

			$('.' + this.classNames.firstColActive + ', .' + this.classNames.secondColActive + ', .' + this.classNames.thirdColActive).removeClass(allActiveClasses);

			if(window.philips.utilities.env.testMedia(450)) { 
				// One column layout
				this.doNodeInsert(familyTileGridItem, productTileContainer, 0);

			}else if(window.philips.utilities.env.testMedia(700)){
				// Two Column Layout
				this.switchTwoColumn(index, familyTileGridItem, productTileContainer);
		
			}else{
				// Three Column Layout
				this.switchThreeColumn(index,familyTileGridItem, productTileContainer);			
			}

		},

		/**
		 * Invoked on page load and filter, this updates the product counts for each category tile heading, and the main section heading count
		 * @method		updateProductCountsAndReturnEmpty
		 * @namespace	productListing
		 */
		'updateProductCountsAndReturnEmpty': function(){
			var i, len, familyTile, familyHeading, productTileContainer,
				productTiles, numFilteredTiles, productCount, localHeadings,
				singleProductTiles = $(this.selectors.singleProductTiles).parent(),
				emptyFamilies = $(),
				context = this;

			function isTileFiltered(){
				/* jshint validthis:true */

				return $(this).data(context.classNames.filteredOut);
			}

			for(i = 0, len = this.familyTiles.length; i < len; i++){
				// Find all necessary elements
				familyTile              = this.familyTiles.eq(i);
				familyHeading           = familyTile.find(this.selectors.familyHeading);
				productTileContainer    = familyTile.siblings(this.selectors.productTileContainer);
				localHeadings           = familyHeading.add(productTileContainer.find(this.selectors.familyHeading));
				productTiles            = productTileContainer.find(this.selectors.productTileSet);

				numFilteredTiles        = productTiles.filter(isTileFiltered).length;

				productCount            = productTiles.length - numFilteredTiles;


				if(familyTile.closest('.' + this.classNames.tileActive).length){
					localHeadings = localHeadings.add(this.selectors.activeProductsHeading);
					if(productCount === 0){
						this.closeProductPanel($('.' + this.classNames.activeProducts));
					}
				}

				// Set the product count on the family tile heading
				localHeadings.attr('data-element-meta-value', productCount);

				// Increment the total product count
				this.productTotal += productCount;
				if(productCount === 0){
					emptyFamilies = emptyFamilies.add(familyTile.parent());
				}
			}

			this.productTotal += singleProductTiles.length - singleProductTiles.filter(isTileFiltered).length;

			// Set the total product count on the product listing section heading (and reset afterwards)
			this.listingHeading.attr('data-element-meta-value', this.productTotal);
			this.productTotal = 0;

			return emptyFamilies;
		},

		/**
		 * [description]
		 * @param {Object} e		jQuery event object
		 * @method					handleFilterChange
		 */
		'handleFilterChange': function(e){
			var specialtyTiles,
                self                 = this,
				familyTileGridItem   = $('.' + this.classNames.tileActive),
				productTileContainer = $('.' + this.classNames.activeProducts),
				filteredOutClass     = this.classNames.filteredOut,
				familyTiles          = $(this.selectors.familyTileGridItem),
                specialtyDataAttr    = this.selectors.specialtyDataAttr,
                attrFilter           = '[' + specialtyDataAttr + ']',
				filteredTiles        = $(),
				unfilteredTiles;

            var filterHandler = function() {

                var elem = $( this ),
                    include = true,
                    specialties = self.activeSpecialtyArr,
                    dataValue = elem.attr( specialtyDataAttr ).split( ',' );

                $.each( dataValue, function( i, value ) {
                    include = specialties.indexOf( value ) === -1;
                    return include;
                });

                return include;
            };

			this.activeSpecialty = $(e.target).val();
            this.activeSpecialtyArr = this.activeSpecialty.split(',');

			specialtyTiles = $(attrFilter);

			if(this.activeSpecialty !== 'all'){
                filteredTiles = specialtyTiles.filter( filterHandler );
			}
			unfilteredTiles = specialtyTiles.not(filteredTiles);

			filteredTiles.data(filteredOutClass, true);
			unfilteredTiles.data(filteredOutClass, false);

			filteredTiles = filteredTiles.add(this.updateProductCountsAndReturnEmpty());
			unfilteredTiles = unfilteredTiles.add(familyTiles.not(filteredTiles));

			filteredTiles.addClass(filteredOutClass);
			unfilteredTiles.removeClass(filteredOutClass);


			if(productTileContainer.length){
				this.placeProductTiles(familyTileGridItem, productTileContainer);
			}

		}
	};



	// Initialize fixed row height for the responsive product listing components
	window.philips.libs.fixedRowHeight.create(productListing.selectors.familyTileGrid, productListing.selectors.allTiles);

	return productListing.setup();
}(
    // Dependencies
    jQuery,
    window.philips.utilities.env
));
