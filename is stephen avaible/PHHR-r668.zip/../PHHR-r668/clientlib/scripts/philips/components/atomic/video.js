/**
 * @issue: The Philips-provided file does not pass jshint requirements
 **/

/**
 * Video
 * see: http://images.philips.com/s7sdk/2.3/docs/jsdoc/index.html
 * Namespace with a factory creating component instances on document.ready
 * @namespace
 * @property {Array} instances - All the component instances
 */
window.philips = window.philips || {};

window.philips.components.atomic.video = (function( $ ){
    
    var noVideo = window.philips.utilities.env.isIE8 && !window.philips.utilities.hasFlash;

    /**
     *
     * @param element
     * @param params
     * @constructor
     */
    function Video( element, params ){
        this._instanceId = Video.getUID();
        this._$element = $(element);
        this._params = params;
        this._events = {};

        this.initialize();

        this._$element.data('component', this);

        // registering initialized instance
        Video.registerInstance(this);
    }

    // static
    Video.instances = [];
    Video._UID = Date.now();

    Video.VIDEOS_INITIALISED = 'videosInitialised';
    Video.VIDEO_RESIZED = 'videoResized';
    Video.VIDEO_FULLSCREEN = 'videoFullscreen';
    Video.VIDEO_PLAYING = 'videoPlaying';
    Video.VIDEO_PAUSING = 'videoPausing';
    Video.FULLSCREEN_RESIZE = 'fullscreenResize';

    Video.uriS7Utils = 'http://images.philips.com/s7sdk/2.3/js/s7sdk/utils/Utils.js';
    Video.uriServer = 'http://images.philips.com/is/image/';
    Video.uriVideo = 'http://images.philips.com/is/content/';

    Video.classnameInset = 'p-inset';
    Video.classnameIsPlaying = 'p-is-playing';
    Video.classnameIsFullscreen = 'p-is-fullscreen';
    Video.classnameIsMuted = 'p-is-muted';
    Video.classnameHover = 'p-hover';

    Video.registerInstance = function( inst ){
        this.instances.push(inst);
    };

    Video.getUID = function(){
        return (Video._UID++).toString(36);
    };

    Video.pauseInstances = function( except ){
        for( var i = 0; i < Video.instances.length; i++ ){
            var obj = Video.instances[i];
            if( obj !== except ){
                obj.pause();
            }
        }
    };

    Video.toString = function(){
        return '[object Video]';
    };

    // private
    Video.prototype._instanceId = '';
    Video.prototype._events;
    Video.prototype._$element;
    Video.prototype._params;
    Video.prototype._containerId;
    Video.prototype._controls;
    Video.prototype._width = 0;
    Video.prototype._height = 0;
    Video.prototype._controlsWidth = 0;
    Video.prototype._controlsHeight = 0;
    Video.prototype._isFullScreen = false;

    // video
    Video.prototype._videoPlayer;
    Video.prototype._$videoPlayer;
    Video.prototype._videoDuration;

    // video balk
    Video.prototype._$scrubBar;
    Video.prototype._scrubBarWidth = 0;
    Video.prototype._scrubBarHorizontalMargin = 0;
    Video.prototype._hasScrubBar = false;
    Video.prototype._$scrubBarSiblings;
    Video.prototype._$scrubBarPlayed;
    Video.prototype._$scrubBarLoaded;

    Video.prototype._$playPause;
    Video.prototype._$fullScreen;

    Video.prototype._$mute;

    Video.prototype._$volume;
    Video.prototype._$volumeDrag;
    Video.prototype._volumeOver = false;
    Video.prototype._volumeDragging = false;
    Video.prototype._volumeDragNum = 0;
    Video.prototype._volumeMinTop = 2;
    Video.prototype._volumeMaxTop = 66;
    Video.prototype._volumeRange = Video.prototype._volumeMaxTop - Video.prototype._volumeMinTop;
    Video.prototype._volumeDragTop = 0;
    Video.prototype._volumeValue = 0;
    Video.prototype._isVideoplayerInitialised = 0;

    // public
    Video.hasComponentResizeListener = false;

    Video.prototype.initialize = function(){

        this._componentId = this._$element.attr('id') || this.getId('p-video');
        this._$element.attr('id', this._componentId);

        this._containerId = this.getId('container');
        this._videoplayerId = this.getId('videoPlayer');
        this._videoElement = this._$element.find('video').detach();
        this._autoplay = !!this._videoElement.attr('autoplay');
        this._posterImage = this._videoElement.attr('poster');
        this._aspectRatio = (this._videoElement.attr('width') || this._videoElement.width()) / (this._videoElement.attr('height') || this._videoElement.height());

        this._$controls = this._$element.find('.p-controls');
        this._hasControls = true;
        this._controlsHeight = this._$controls.outerHeight(true);

        this.width(this._$element.parent().width());
        this.height(this._$element.parent().height());

        this._$scrubBar = this._$controls.find('.p-scrub-bar');
        this._$playPause = this._$controls.find('.p-play-pause');
        this._$fullScreen = this._$controls.find('.p-fullscreen');
        this._$mute = this._$controls.find('.p-mute');
        this._$volume = this._$controls.find('.p-volume');
        this._$volumeDrag = this._$volume.find('div:first-child');
        this._volumeOver = false;
        this._volumeDragging = false;
        this._volumeDragNum = 0;
        this._volumeMinTop = 2;
        this._volumeMaxTop = 66;
        this._volumeRange = this._volumeMaxTop - this._volumeMinTop;
        this._volumeDragTop = 0;
        this._volumeValue = 0;

        // videoplayer params
        this._params.push('serverurl', Video.uriServer);
        this._params.push('videoserverurl', Video.uriVideo);
        this._params.push('asset', this._videoElement.attr('src'));
        this._params.push('posterimage', this._posterImage ? this._posterImage : 'none');

        this._params.push('stagesize', String(this.width()), String(this.height()));
        this._params.push('autoplay', this._autoplay ? '1' : '0');

        // todo: not working in Chrome
        this._params.push('singleclick', 'playPause');
        this._params.push('iconeffect', '1,-1,0.3,0');

        this._container = new window.s7sdk.Container(this._componentId, this._params, this._containerId);
        this._$container = $(this._container.obj);
        //        this._container.resize(this.width(), this.height());

        this._container.addEventListener(window.s7sdk.event.ResizeEvent.COMPONENT_RESIZE, this.onResize.bind(this));
        this._container.addEventListener(window.s7sdk.event.ResizeEvent.FULLSCREEN_RESIZE, this.onResize.bind(this));
        this._container.addEventListener(window.s7sdk.event.ResizeEvent.WINDOW_RESIZE, this.onResize.bind(this));

        this._videoPlayer = new window.s7sdk.video.VideoPlayer(this._containerId, this._params, this._videoplayerId);
        //        this._videoPlayer.resize(this.width(), this.videoPlayerHeight(true) );
        this._$videoPlayer = $(this._videoPlayer.obj);

        //        console.log(this.width(), this.videoPlayerHeight(true));

        this._videoPlayer.addEventListener(s7sdk.event.CapabilityStateEvent.NOTF_VIDEO_CAPABILITY_STATE, this.handleCapabilityState.bind(this), false);
        this._videoPlayer.addEventListener(s7sdk.event.VideoEvent.NOTF_DURATION, this.handleVideoEvent.bind(this), false);
        this._videoPlayer.addEventListener(s7sdk.event.VideoEvent.NOTF_CURRENT_TIME, this.handleVideoEvent.bind(this), false);
        this._videoPlayer.addEventListener(s7sdk.event.VideoEvent.NOTF_LOAD_PROGRESS, this.handleVideoEvent.bind(this), false);
        this._videoPlayer.addEventListener(s7sdk.event.AssetEvent.ASSET_CHANGED, this.handleAssetChanged.bind(this), false);

        if( s7sdk.browser.device.name != 'iphone' ){
            this._$playPause.on('click', this.togglePlayPause.bind(this));
            this._$fullScreen.on('click', this.toggleFullscreen.bind(this));
            this._$mute.on('click', this.toggleMute.bind(this));

            this._hasScrubBar = this._$scrubBar.length !== 0;
            this.calculateScrubbarSize();

            if( this._hasScrubBar ){
                this._$scrubBar.on('click', this.handleScrubbarClick.bind(this));
            }
            this._$scrubBarSiblings = this._$scrubBar.siblings();
            this._$scrubBarPlayed = this._$scrubBar.find('.p-played');
            this._$scrubBarLoaded = this._$scrubBar.find('.p-loaded');
            this._$controls.appendTo(this._$container);
        } else {
            // this._$fullScreen.on('click', this.toggleFullscreen.bind(this));
            this._hasControls = false;
            this._$controls.remove();
        }

        // $volume.click(toggleVolume);
        if( this._$volume.length ){
            this.setVolumeView();
            this._$volume.hover(this.handleVolumeOver.bind(this), this.handleVolumeOut.bind(this)).hammer({ drag_max_touches: 0}).on('touch dragstart', this.handleVolumeDragStart.bind(this)).on('touch drag', this.handleVolumeDragging.bind(this)).on('release dragend', this.handleVolumeDragEnd.bind(this));
        }
        //
        //        this.setDefaultValues();
        //        this.setSize();
        //
        //        window.philips.events.trigger(Video.VIDEO_INITIALISED, this );

        var _this = this;
        setTimeout(function(){
            _this.onResize();
        }, 100);
    };

    // public
    Video.prototype.getId = function( s ){
        return 'p-' + s + '-' + this._instanceId;
    };

    Video.prototype.width = function( size ){
        if( typeof(size) != 'undefined' ){
            this._width = size;
            //            this.height( this.getHeightFromAspectRatio(this._width) );
            return this;
        }

        return this._width;
    };

    Video.prototype.height = function( size ){
        if( typeof(size) != 'undefined' ){
            this._height = size;
            return this;
        }

        return this._height;
    };

    Video.prototype.controlsHeight = function( update ){
        if( update ){
            this._controlsHeight = this._$controls.outerHeight(true);
        }

        return this._controlsHeight;
    };

    Video.prototype.videoPlayerHeight = function( update ){
        if(this._hasControls){
            return this.height() - this.controlsHeight(update);
        } else {
            return this.height();
        }
    };

    Video.prototype._loopCallAdobeHack = false;
    
    Video.prototype.onResize = function( e ){

        console.log('isFullScreen', this._isFullScreen);

        if( this._loopCallAdobeHack ){
            this._loopCallAdobeHack = false;
            return;
        }

        if( !this._isFullScreen ){

            this.width(this._$element.parent().width());
            this.height(this._$container.height());
            this._videoPlayer.resize(this.width(), this.videoPlayerHeight());

        } else {
            //            this._width = e ? e.s7event.w : this._width;
            this.width(philips.utilities.getWindowWidth());
            this.height(philips.utilities.getWindowHeight());

            // container fix for ipad . adobe s7container does not work correctly
            this._loopCallAdobeHack = true;
            this._container.resize(this.width(), this.height());

            this._videoPlayer.resize(this.width(), this.videoPlayerHeight());

            // container fix for ipad . adobe s7container does not work correctly
            this._$container.css({
                'position': 'absolute',
                'top': 0
            });

            console.log('onResize', this.width(), this.height(), this.videoPlayerHeight());
        }

        if( this._$controls ){
            this._$controls.css('position', 'absolute');
            this._$controls.css('top', this.videoPlayerHeight());
            this._$controls.css('width', this.width());
        }

        this.calculateScrubbarSize();
    };

    Video.prototype.pause = function(){
        if( this._isPlaying ){
            this._videoPlayer.pause();
        }
    };

    Video.prototype.play = function(){
        if( !this._isPlaying ){
            this.endToStart();
            this._videoPlayer.play();
        }
    };

    Video.prototype.getHeightFromAspectRatio = function( width ){
        return Math.ceil(width / this._aspectRatio);
    };

    Video.prototype.toggleFullscreen = function( e ){
        console.log('toggleFullscreen');

        if( this._isFullScreen ){
            this._isFullScreen = false;
            this._container.cancelFullScreen();
        } else {
            this._isFullScreen = true;
            this._container.requestFullScreen();
        }

        // hack for adobe s7container. fullscreen event is not triggerd when going fullscreen
        this.onResize();

    };

    Video.prototype.togglePlayPause = function(){
        console.log('Video.prototype.togglePlayPause', this._isPlaying);
        if( this._isPlaying ){
            this._isPlaying = false;
            this._videoPlayer.pause();
        } else {
            this._isPlaying = true;
            this.endToStart();
            this._videoPlayer.play();
        }
        this.setPlayPauseView();
    };

    Video.prototype.useResizeListener = function( enable ){
        if( typeof(enable) == 'undefined' ){
            enable = true;
        }

        if( enable && !this.hasComponentResizeListener ){
            //                alert(eventComponentResize);
            //                container.addEventListener(eventComponentResize,handleComponentResize,false);
            //                hasComponentResizeListener = true;
        } else if( !enable && this.hasComponentResizeListener ){
            this._container.removeEventListener(s7sdk.event.ResizeEvent.COMPONENT_RESIZE, this.onResize.bind(this), false);
            this.hasComponentResizeListener = false;
        }
    };

    Video.prototype.endToStart = function(){
        if( this._videoPlayer.getCurrentTime() === this._videoDuration ){
            this._videoPlayer.seek(0);
        }
    };

    Video.prototype.checkInit = function(){
        if( !this._isVideoplayerInitialised ){
            var $icon = this._$videoPlayer.find('.s7iconeffect').empty();
            $icon.append('<div class="p-play-button"><i class="p-icon-play"></i></div>');
            if( $icon.length ){
                // check video implementation
                var $checkVideo = this._$videoPlayer.find('video');
                isHTML5Video = $checkVideo.length !== 0;
                if( isHTML5Video ){
                    $video = $checkVideo;
                    video = $checkVideo.get(0);
                    //                        $video.on('click',togglePlayPause);
                }
                // set iconEffect and manually attach event listener (for IE)
                $iconeffect = $icon;
                //                    $iconeffect.on('click',togglePlayPause);
                this._isVideoplayerInitialised = true;
            }
        }
    };

    /**
     *
     */
    Video.prototype.calculateScrubbarSize = function(){
        //        console.log('Video::calculateScrubbarSize', this._width );
        //        var siblingsWidth = 0,
        //            padding = $controls.outerWidth() - $controls.width(),
        //            width = $controls.width() - padding + 1;
        //        $scrubBarSiblings.each(function(i, el) {
        //            if($(el).is(':visible')) {
        //                siblingsWidth += $(el).outerWidth(true);// + siblingHorizontalMargin;
        //            }
        //        });
        //        scrubBarWidth = width - siblingsWidth - scrubBarHorizontalMargin - 1;
        //        $scrubBar.width(scrubBarWidth);
        if( this._hasScrubBar ){
            // re-calculate
            this._scrubBarWidth = 0;
            var self = this;
            this._$scrubBar.siblings().each(function( i, el ){
                self._scrubBarWidth += $(el).outerWidth(true);
            });

            this._scrubBarHorizontalMargin = parseInt(this._$scrubBar.css('margin-left'), 10)
                + parseInt(this._$scrubBar.css('margin-right'), 10);
            this._scrubBarWidth = this._width - this._scrubBarWidth - this._scrubBarHorizontalMargin;
            this._$scrubBar.width(this._scrubBarWidth);
        }
    };

    /**
     * Handles the capability state.
     * Used for setting the views for pause/play and mute button.
     * @method
     * @private
     * @param {Event} e Scene 7 event
     */
    Video.prototype.handleCapabilityState = function( e ){
        var state = e.s7event.state, stateCanPause = state.hasCapability(s7sdk.VideoCapabilityState.PAUSE), stateCanUnmute = state.hasCapability(s7sdk.VideoCapabilityState.UNMUTE);
        if( this._isPlaying !== stateCanPause ){
            this._isPlaying = stateCanPause;
            this.setPlayPauseView();
            // pause all other component instances
            if( this._isPlaying ){
                Video.pauseInstances(this);
                this._$element.trigger(Video.VIDEO_PLAYING, this);
            } else {
                this._$element.trigger(Video.VIDEO_PAUSING, this);
            }
        }
        //
        if( this._isMuted !== stateCanUnmute ){
            this._isMuted = stateCanUnmute;
            this.setMuteView();
        }

        this.checkInit();
    };

    /**
     * Handles the video event.
     * Sets the duration, handles the view of the scrub bar.
     * @method
     * @private
     * @param {Event} e Scene 7 event
     */
    Video.prototype.handleVideoEvent = function( e ){

        var eventType = e.s7event.type;
        if( eventType === s7sdk.VideoEvent.NOTF_DURATION ){
            this._videoDuration = this._videoPlayer.getDuration();
        } else if( eventType === s7sdk.VideoEvent.NOTF_LOAD_PROGRESS ){
            if( this._videoDuration > 0 ){
                var partLoaded = this._videoPlayer.getLoadedPosition() / this._videoDuration;
                this._$scrubBarLoaded.width(100 * partLoaded + '%');
            }
        } else if( eventType === s7sdk.VideoEvent.NOTF_CURRENT_TIME ){
            var partPlayed = this._videoPlayer.getCurrentTime() / this._videoDuration;
            this._$scrubBarPlayed.width(100 * partPlayed + '%');
            //            } else if (eventType===s7sdk.VideoEvent.NOTF_VIDEO_END) {
            //
        } else {
            //                console.log('handleVideoEvent',e); // log
        }
    };

    /**
     * Handles the asset change event.
     * The video asset has changed. All computational values have to be reset to their defaults.
     * @method
     * @private
     * @param {Event} e
     */
    Video.prototype.handleAssetChanged = function( e ){
        this.setDefaultValues(e.s7event.asset);
    };

    /**
     * Handles scrubbing
     * @method
     * @private
     * @param {Event} e
     */
    Video.prototype.handleScrubbarClick = function( e ){
        var offsetX = this._$scrubBar.offset().left, clickX = e.pageX, relativeX = clickX
                - offsetX, seedPart = relativeX / this._$scrubBar.width(), toTime = seedPart * this._videoDuration;
        this._videoPlayer.seek(toTime);
    };

    Video.prototype.setPlayPauseView = function(){
        this._$playPause.toggleClass(Video.classnameIsPlaying, this._isPlaying);
    };

    Video.prototype.setMuteView = function(){
        this._$mute.toggleClass(Video.classnameIsMuted, this._isMuted);
    };

    /**
     * Toggles the mute state of the videoplayer depending on the capability.
     * This will cause the CapabilityStateEvent.NOTF_VIDEO_CAPABILITY_STATE to be dispatched if the state actually changes.
     * @method
     * @private
     */
    Video.prototype.toggleMute = function(){
        if( this._videoPlayer.getVolume() == 0 && this.canMute() ){
            this._videoPlayer.setVolume(1);
        } else if( this.canMute() ){
            this._videoPlayer.mute();
        } else {
            this._videoPlayer.unmute();
        }
    };

    /**
     * Test if the volume can be muted.
     * @returns {boolean}
     */
    Video.prototype.canMute = function(){
        return this._videoPlayer.getCapabilityState().hasCapability(s7sdk.VideoCapabilityState.MUTE);
    };

    /**
     * Handles over event on the volume button
     * @method
     * @private
     */
    Video.prototype.handleVolumeOver = function(){
        this._volumeOver = true;
        this._$volume.addClass(Video.classnameHover);
    };

    /**
     * Handles out event on the volume button
     * @method
     * @private
     */
    Video.prototype.handleVolumeOut = function(){
        this._volumeOver = false;
        if( !this._volumeDragging ){
            this._$volume.removeClass(Video.classnameHover);
        }
    };

    /**
     * Handles drag-start event on the volume drag button
     * @method
     * @private
     */
    Video.prototype.handleVolumeDragStart = function(){
        this._volumeDragNum = 0;
        this._volumeDragging = true;
        this._volumeDragTop = parseInt(this._$volumeDrag.css('top') || 0, 10);
    };

    /**
     * Handles drag event on the volume drag button
     * @method
     * @private
     * @param {object} e The event
     */
    Video.prototype.handleVolumeDragging = function( e ){
        this._volumeDragNum++;
        var gesture = e.gesture;
        if( gesture && this._volumeDragNum > 1 ){
            if( this._volumeDragNum === 2 && !this.canMute() ){
                this.toggleMute();
            }
            var startEventTouches = gesture.startEvent.touches, startPageY = startEventTouches[0].pageY, touches = gesture.touches;
            for( var i = 0, len = touches.length; i < len; i++ ){
                var top = touches[i].pageY - startPageY + this._volumeDragTop;
                if( top < 2 ){
                    top = this._volumeMinTop;
                } else if( top > 60 ){
                    top = this._volumeMaxTop;
                }
                this._volumeValue = 1 - (top - this._volumeMinTop) / this._volumeRange;
                this._$volumeDrag.css({top: top});
                this._videoPlayer.setVolume(this._volumeValue);
            }
        }
    };

    /**
     * Handles drag-end event on the volume drag button
     * @method
     * @private
     */
    Video.prototype.handleVolumeDragEnd = function(){
        this._volumeDragging = false;
        if( this._volumeDragNum === 1 ){
            this.toggleMute();
            this.setVolumeView();
        } else {
            if( !this._volumeOver ){
                this._$volume.removeClass(Video.classnameHover);
            }
        }
    };

    Video.prototype.setDefaultValues = function( mediaSet ){
        var mediaSetDescription = mediaSet;
        this._videoDuration = philips.utilities.LARGEST_NUMBER;
        if( mediaSetDescription ){
            // todo: possible change in aspect ratio, size, etc...
            var currentAsset = mediaSetDescription.items[mediaSetDescription.level];
            assetW = currentAsset.width;
            assetH = currentAsset.height;
        }
    };

    Video.prototype.setVolumeView = function( mediaSet ){
        if( this.canMute() ){
            this._volumeValue = this._videoPlayer.getVolume();
            this._$volumeDrag.css({
                top: Math.round(this._volumeMinTop + (1 - this._volumeValue) * this._volumeRange)
            });
        } else {
            this._$volumeDrag.css({top: this._volumeMaxTop});
        }
    };

    if( $ ){
        /**
         * initialise components on document ready
         */
        $(function(){
            $components = $('.p-video');

            if( $components.length !== 0 ){
                if( noVideo ){
                    $components.find('.p-get-flash').show();
                }
                // todo: make getScript obsolete by implementing global atomic/laggregated dependencies
                //                initSizeBeforeLoad();
                $.getScript(Video.uriS7Utils, function(){
                    s7Include = window.s7sdk.Util.lib.include;
                    //
                    s7Include('s7sdk.common.Container');
                    s7Include('s7sdk.event.Event');
                    s7Include('s7sdk.video.VideoPlayer');
                    //
                    var countdown = $components.length;
                    $components.each(function( i, component ){
                        var s7params = new window.s7sdk.ParameterManager();
                        s7params.addEventListener(window.s7sdk.Event.SDK_READY, function(){
                            var video = new Video(component, s7params);
                            countdown--;
                            if( countdown === 0 ){
                                window.philips.events.trigger(Video.VIDEOS_INITIALISED, $components.length);
                            }
                        }, false);
                        s7params.init();
                    });
                });
            }
        });
    }

    return Video;

})(jQuery);
