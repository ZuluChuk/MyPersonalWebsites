window.philips.components.aggregated.main = (function(

        autocomplete
){
    var acShowDuration = (Modernizr.csstransitions? 0 : 300);
        

	/**
	 * Init the autocomplete functionality for secondary search
	 */
		
			
	var el = $('.p-main-search-form').find('.p-query');
	
	if ( !el.length ){

		return;
	}
	
	autocomplete({
	
		el: el,
		wrapper: '.p-main-search',
		resultsClassName: 'p-main-search-ac-results',
		align: 'left',
		submitOnSelect: false,
		usePartialComplete: false,
		show: function(){
			
			$(this).fadeIn(acShowDuration).addClass('on');
		},
		hide: function(){
			
			$(this).fadeOut(acShowDuration).removeClass('on');
		},
		submit: function(){
			
			$(this).parents('form').submit();
		}
    });
}(

    window.philips.libs.autoComplete

));
