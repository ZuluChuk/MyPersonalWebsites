//////////////////
// Dependencies //
//////////////////
//	clientlib/scripts/vendorsclientlib/scripts/philips/jquery/jquery-1.10.1.min.js (or 2.0.2)
//	clientlib/scripts/philips/philips.js

window.philips.components.atomic.tile = (function(
    
    // Dependencies
    $

){
	'use strict';

    /**
     * Namespace
     *
     * @namespace component
     * @private
     */
    var component = {

        selectors: {
            context: '.p-tile-cta'
        },
        
        /**
         * Kicks off component's initiation.
         *
         * @method              init
         * @memberof            component
         * @returns {Object}    component
         */
        init: function() {
            
            this.context = $( this.selectors.context );

            this.context.css( 'cursor', 'pointer' );
            this.context.on( 'click', this.handleLink );
            
            return this;
        },

        /**
         * Handle navigating the browser to the tiles main URL
         *
         * @method              handleLink
         * @memberof            component
         */
        handleLink: function(e) {
            
            var tile = $( e.currentTarget ),
                url = tile.find( 'a' )[0].href;

            window.location.href = url;
        }
    };

    return component.init();

}(
    
    // Dependencies
    jQuery

));
